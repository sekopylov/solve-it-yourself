# Атрибуция и лицензии

Условия исходных данных сохраняются для производных примеров. Единой лицензии,
которая отменяет условия источников, нет. В частности, записи RuArena имеют
CC BY-NC 4.0: используйте их в рамках некоммерческого исследовательского проекта.
Сохраняйте ссылки и атрибуцию авторам источников. Для каждой новой строки
источник, ревизия и лицензия указаны в metadata; её parent_id ссылается на v4.
Карточки источников находятся в data/expanded_v4/source_cards.

| Источник | Исходных запросов | Производных пар | Лицензия карточки |
|---|---:|---:|---|
| [DigitalLearningGmbH/MATH-lighteval](https://huggingface.co/datasets/DigitalLearningGmbH/MATH-lighteval) | 650 | 2600 | MIT |
| [IlyaGusev/ru_turbo_alpaca](https://huggingface.co/datasets/IlyaGusev/ru_turbo_alpaca) | 1783 | 7132 | CC-BY-4.0 |
| [MERA-evaluation/MERA](https://huggingface.co/datasets/MERA-evaluation/MERA) | 1729 | 6916 | MIT |
| [OpenAssistant/oasst1](https://huggingface.co/datasets/OpenAssistant/oasst1) | 937 | 3748 | Apache-2.0 |
| [lmarena/ruarena-user-preference-7k](https://huggingface.co/datasets/lmarena/ruarena-user-preference-7k) | 350 | 1400 | CC-BY-NC-4.0 |
| [mizinovmv/ru_OpenMathInstruct-2](https://huggingface.co/datasets/mizinovmv/ru_OpenMathInstruct-2) | 551 | 2204 | CC-BY-4.0 |

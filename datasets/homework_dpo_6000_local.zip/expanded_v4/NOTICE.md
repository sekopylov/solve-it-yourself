# Происхождение и условия использования

| Источник | Записей | Лицензия |
|---|---:|---|
| [MERA-evaluation/MERA](https://huggingface.co/datasets/MERA-evaluation/MERA) | 1729 | MIT |
| [IlyaGusev/ru_turbo_alpaca](https://huggingface.co/datasets/IlyaGusev/ru_turbo_alpaca) | 1783 | CC-BY-4.0 |
| [OpenAssistant/oasst1](https://huggingface.co/datasets/OpenAssistant/oasst1) | 937 | Apache-2.0 |
| [lmarena/ruarena-user-preference-7k](https://huggingface.co/datasets/lmarena/ruarena-user-preference-7k) | 350 | CC-BY-NC-4.0 |
| [mizinovmv/ru_OpenMathInstruct-2](https://huggingface.co/datasets/mizinovmv/ru_OpenMathInstruct-2) | 551 | CC-BY-4.0 |
| [DigitalLearningGmbH/MATH-lighteval](https://huggingface.co/datasets/DigitalLearningGmbH/MATH-lighteval) | 650 | MIT |

Это смешанный набор для исследовательского проекта. Единой лицензии, отменяющей лицензии источников, нет. RuArena имеет CC BY-NC 4.0 (некоммерческое использование); у остальных записей собственные условия, указанные в metadata. Сохраняйте атрибуцию источникам и их авторам. Карточки источников приложены в source_cards; точные ревизии — в sources.json.

# Происхождение и лицензии

Условия источников сохраняются для производных пар. Единой лицензии, отменяющей лицензии источников, нет. No Robots и RuArena имеют CC BY-NC 4.0 — некоммерческое использование с атрибуцией. У остальных строк свои условия; источник и ревизия сохранены в metadata. Карточки источников приложены.

| Источник | Исходных запросов | Лицензия карточки |
|---|---:|---|
| [DigitalLearningGmbH/MATH-lighteval](https://huggingface.co/datasets/DigitalLearningGmbH/MATH-lighteval) | 1644 | MIT |
| [HuggingFaceH4/no_robots](https://huggingface.co/datasets/HuggingFaceH4/no_robots) | 1006 | CC-BY-NC-4.0 |
| [IlyaGusev/ru_turbo_alpaca](https://huggingface.co/datasets/IlyaGusev/ru_turbo_alpaca) | 1783 | CC-BY-4.0 |
| [MERA-evaluation/MERA](https://huggingface.co/datasets/MERA-evaluation/MERA) | 1729 | MIT |
| [OpenAssistant/oasst1](https://huggingface.co/datasets/OpenAssistant/oasst1) | 937 | Apache-2.0 |
| [lmarena/ruarena-user-preference-7k](https://huggingface.co/datasets/lmarena/ruarena-user-preference-7k) | 350 | CC-BY-NC-4.0 |
| [mizinovmv/ru_OpenMathInstruct-2](https://huggingface.co/datasets/mizinovmv/ru_OpenMathInstruct-2) | 551 | CC-BY-4.0 |

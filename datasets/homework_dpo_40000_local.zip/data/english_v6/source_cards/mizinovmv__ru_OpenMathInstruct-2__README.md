---
language:
- ru
- en
license: cc-by-4.0
size_categories:
- 10K<n<100K
task_categories:
- question-answering
- text-generation
pretty_name: OpenMathInstruct-2
dataset_info:
  features:
  - name: problem
    dtype: string
  - name: generated_solution
    dtype: string
  - name: expected_answer
    dtype: string
  - name: problem_source
    dtype: string
  - name: ru_problem
    dtype: string
  - name: ru_generated_solution
    dtype: string
  splits:
  - name: train
    num_bytes: 309450294
    num_examples: 90197
  download_size: 138430837
  dataset_size: 309450294
tags:
- math
- nvidia
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
---

# OpenMathInstruct-2

Переведено на русский [Qwen2.5-32B-Instruct-GPTQ-Int8](https://huggingface.co/datasets/mizinovmv/ru_OpenMathInstruct-2/blob/main/ru_OpenMathInstruct-2_Qwen2.5.ipynb)

[OpenMathInstruct-2](https://huggingface.co/datasets/nvidia/OpenMathInstruct-2) is a math instruction tuning dataset with 14M problem-solution pairs 
generated using the [Llama3.1-405B-Instruct](https://huggingface.co/meta-llama/Llama-3.1-405B-Instruct) model.

The training set problems of [GSM8K](https://github.com/openai/grade-school-math)
and [MATH](https://github.com/hendrycks/math) are used for constructing the dataset in the following ways: 
- *Solution augmentation*: Generating chain-of-thought solutions for training set problems in GSM8K and MATH. 
- *Problem-Solution augmentation*: Generating new problems, followed by solutions for these new problems.      

OpenMathInstruct-2 dataset contains the following fields:

- **problem**: Original problem from either the GSM8K or MATH training set or augmented problem from these training sets.
- **generated_solution**: Synthetically generated solution.
- **expected_answer**: For problems in the training set, it is the ground-truth answer provided in the datasets. **For augmented problems, it is the majority-voting answer.**
- **problem_source**: Whether the problem is taken directly from GSM8K or MATH or is an augmented version derived from either dataset.
---
license: cc-by-nc-4.0
dataset_info:
  features:
  - name: model_a
    dtype: string
  - name: model_b
    dtype: string
  - name: winner
    dtype: string
  - name: conversation_a
    dtype: string
  - name: conversation_b
    dtype: string
  splits:
  - name: train
    num_bytes: 57602290
    num_examples: 6799
  download_size: 25030357
  dataset_size: 57602290
configs:
- config_name: default
  data_files:
  - split: train
    path: data/train-*
language:
- ru
size_categories:
- 1K<n<10K
task_categories:
- text-generation
tags:
- LLM
- NLP
- Human feedback
- Model comparison
- Text generation

---
# Russian LLM Arena
## Dataset Description

The dataset comprises a massive collection of **LLM evaluations** and **human preferences**, featuring head-to-head comparisons of **17 language models**. Sourced from the open platform **LLM Arena**, it contains detailed logs of user interactions, providing a robust foundation for analyzing **model rankings, leaderboard scores, and rating systems**.

### Key Fields
- **model_a** / **model_b** — Names of compared models.
- **winner** — Result of the comparison: `model_a`, `model_b`, `tie`, or `bothbad`.
- **conversation_a** / **conversation_b** — User query (`role: user`) and model response (`role: assistant`).

Each row represents a single vote where a user evaluates the performance of two chatbots (model_a and model_b) on the same prompt. The key field, winner, captures the user's preference (model_a, model_b, tie, or bothbad), while conversation_a and conversation_b contain the full text of the user query and the corresponding model responses.

By utilizing this dataset, researchers and developers can advance their understanding of large language models, benchmark performance across various tasks (like coding and generating text), and develop more sophisticated scoring and ranking methodologies. This data is invaluable for anyone working on benchmarks, improving conversational AI, and understanding Russian language capabilities in the LLM landscape.

For access to the complete, ongoing dataset or to commission a similar large-scale data collection for LLM evaluations and benchmarks, please contact us to discuss your specific requirements: roman@kucev.com
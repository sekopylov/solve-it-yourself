"""Package the 40k dataset and document the English addition."""
from collections import Counter
import json
import shutil
import zipfile
from source_records import ROOT
from curate_600 import load_jsonl
from build_adversarial_v5 import digest

OUT=ROOT/"data/english_v6"


def main():
    s=json.loads((OUT/"stats.json").read_text())
    assert json.loads((OUT/"validation_results.json").read_text())["status"]=="passed"
    parents=load_jsonl(OUT/"combined/parents_8000.jsonl")
    sources=[]
    for dataset in sorted({p["source_dataset"] for p in parents}):
        group=[p for p in parents if p["source_dataset"]==dataset];p=group[0]
        sources.append(dict(dataset=dataset,url="https://huggingface.co/datasets/"+dataset,
            revision=p["source_revision"],license=p.get("source_license",p.get("source_license_in_card")),parent_requests=len(group)))
    (OUT/"sources.json").write_text(json.dumps(sources,ensure_ascii=False,indent=2)+"\n")
    cards=OUT/"source_cards";cards.mkdir(exist_ok=True)
    for p in (ROOT/"data/expanded_v4/source_cards").glob("*"):
        if p.is_file():shutil.copyfile(p,cards/p.name)
    shutil.copyfile(ROOT/"data/raw/HuggingFaceH4/no_robots/README.md",cards/"HuggingFaceH4__no_robots__README.md")
    shutil.copyfile(ROOT/"data/adversarial_v5/template_catalog.json",OUT/"template_catalog.json")
    manifest=json.loads((ROOT/"data/research/english_sources_v6.json").read_text())
    manifest += [p for p in json.loads((ROOT/"data/research/expansion_sources_v4.json").read_text()) if p["dataset"]=="DigitalLearningGmbH/MATH-lighteval"]
    (OUT/"source_download_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
    table="\n".join(f"| [{p['dataset']}]({p['url']}) | {p['parent_requests']} | {p['license']} |" for p in sources)
    (OUT/"NOTICE.md").write_text("# Происхождение и лицензии\n\nУсловия источников сохраняются для производных пар. Единой лицензии, отменяющей лицензии источников, нет. No Robots и RuArena имеют CC BY-NC 4.0 — некоммерческое использование с атрибуцией. У остальных строк свои условия; источник и ревизия сохранены в metadata. Карточки источников приложены.\n\n| Источник | Исходных запросов | Лицензия карточки |\n|---|---:|---|\n"+table+"\n")
    text=f"""# Итоговый набор v6: 40 000 DPO-пар

Сохранены все прежние **30 000 пар** v5 и добавлены **10 000 английских пар**. Теперь **23 500 русских / 16 500 английских**, **20 000 educational / 20 000 ordinary**.

| Выборка | Всего | educational | ordinary |
|---|---:|---:|---:|
| train | 36 000 | 18 000 | 18 000 |
| validation | 2 000 | 1 000 | 1 000 |
| test | 2 000 | 1 000 | 1 000 |

## Что добавлено

**2 000 новых исходных английских запросов**: 1 000 учебных и 1 000 обычных. К каждому добавлены четыре варианта v5 — роль преподавателя, рабочая легенда, проверка готового ответа, отмена запрета. Получилось **2 000 исходных + 8 000 обёрнутых = 10 000 новых пар**. Итого в версии 40 000 строк — **8 000 исходных запросов**. Размножение формулировок не означает появления 40 000 независимых задач.

Новые источники запросов/ответов: **No Robots train** — {s['new_sources']['HuggingFaceH4/no_robots']} строк, **MATH train** — {s['new_sources']['DigitalLearningGmbH/MATH-lighteval']} строк. No Robots даёт 1 000 обычных запросов: письма, работа, готовка, бытовое планирование, техника и общие объяснения; ещё несколько формальных упражнений и программных задач отнесены к educational по рубрике проекта. Новая учебная часть преимущественно математическая. Решения MATH и ответы No Robots предоставлены источниками. Официальные test-части этих корпусов не использованы.

Новые метки назначены правилами с выборочным просмотром и индивидуальными исключениями. Это слабая разметка, не независимая человеческая проверка 2 000 новых меток. Все новые исходные строки имеют label_review_status=rule_selected_not_individually_reviewed; обёртки наследуют метку. Ответы полностью не фактчекались. Неоднозначные запросы — review_queue.jsonl, не входят в 40 000. Шаблоны меняют заявленный контекст, но сохраняют исходное условие. Для ordinary одинаковые обёртки не меняют предпочтение содержательного ответа.

## Файлы

- **combined/dpo/train.jsonl** — основной train: 36 000 пар.
- **combined/dpo/validation.jsonl** — 2 000 отложенных пар.
- **combined/test_prompts.jsonl** — 2 000 тестовых диалогов с ожидаемым поведением.
- **combined/dpo/train_light.jsonl** — облегчённая смесь: 21 600 пар (исходные обучающие запросы + по два варианта). Для первого запуска на бесплатном GPU можно использовать её вместо полного train.
- **combined/preference_pairs.jsonl** — все 40 000 пар с id, split, метками и происхождением. Для обучения используется отдельный train, поскольку общий файл содержит test и validation.
- **combined/parents_8000.jsonl** — 8 000 исходных запросов с источниками и ответами.
- **new_parents/labeled_2000.jsonl**, **new_parents/dpo_pairs_2000.jsonl** — только новые английские исходные записи.
- **extension/preference_pairs.jsonl**, **extension/dpo/train.jsonl** — английское дополнение отдельно: 10 000 всех / 9 000 обучающих пар.
- **evaluation/base_only_test_prompts.jsonl** — 400 исходных тестовых запросов без обёрток.
- **evaluation/previous_v5_test_prompts.jsonl** — прежний тест на 1 500 диалогов, сохранён для сопоставимости.
- **novel_attacks/test_prompts.jsonl** — отдельный тест на **1 600 диалогов**: персонажи, предлог сбора датасета, JSON, давление после отказа. Эти семейства не входят в train/validation; тест не входит в число 40 000.
- **sources.json**, **NOTICE.md**, **source_cards/**, **source_download_manifest.json** — атрибуция, лицензии и ревизии.
- **validation_results.json**, **previous_data_checksums.json**, **checksums.json**, **split_manifest.json** — результаты проверок и порядок строк.

В dpo/*.jsonl только prompt/chosen/rejected; метки и источники модели не передаются. Для учебного запроса chosen — отказ; для обычного — ответ источника. В проверке готового ответа черновик сохраняется целиком и не объявляется заранее правильным. Семейства обходов и политика соответствуют v5: смена заявленной роли не отменяет отказ от выполнения конкретного учебного упражнения.

## Разбиение и ограничения

У новых исходных запросов распределение 1 800 train / 100 validation / 100 test. Все четыре варианта наследуют split родителя; обнаруженные общие условия программных задач объединены в группу. Использованы прежние разделённые по split формулировки обёрток. Проверены точные и нормализованные совпадения с прежними запросами и известными английскими оригиналами русских переводов. Дополнительно применён лексический поиск близких формулировок MinHash/SequenceMatcher. Полная семантическая независимость и отсутствие задач в предобучении модели не гарантируются.

Все прежние 30 000 пар сохранены по значениям сообщений, выбранных/отклонённых ответов и split. Исходные файлы v4/v5 не изменены; SHA-256 проверены. Новые ответы сверены с локальными исходными train-файлами. Прямых повторов итоговых диалогов и пересечений проверяемых групп между split нет.

Число независимых тестовых исходных запросов — 400, а не сумма всех обёрток. Метрики считать по parent_id/parent_split_group_id, отдельно для отказов на educational и ложных отказов на ordinary. Новая английская учебная часть в основном состоит из MATH; связь источника, предмета и класса остаётся ограничением набора. Validation/test тоже наследуют слабые метки. Для сопоставимой оценки отдельно используйте прежний тест v5. Устойчивость обходов на моделях не измерялась, обучение не запускалось.

В {s['length_review_pairs']} парах суммарная длина входа и более длинного выхода превышает 6 000 символов — length_review_queue.jsonl. До обучения надо проверить все пары токенизатором выбранной модели. Это не проверка токенного лимита; тексты и решения намеренно не обрезались.

## Воспроизведение

Требуются предыдущие локальные v4/v5, исходный MATH train и Python с numpy/pyarrow. Из корня проекта:

```sh
python3 scripts/fetch_english_v6.py
python3 scripts/prepare_english_v6.py
python3 scripts/build_english_v6.py
python3 scripts/validate_english_v6.py
python3 scripts/report_english_v6.py
```

Всё сохранено локально; Kaggle notebook и запуск обучения не создавались. Архив homework_dpo_40000_local.zip содержит готовые обучающие файлы, полные пары, исходные выбранные запросы, тесты и описание. Большие исследовательские candidates/review_queue остаются локально вне компактного архива.
"""
    (OUT/"README.md").write_text(text);(ROOT/"reports/english_v6.md").write_text(text)
    skip={"candidates.jsonl","review_queue.jsonl","audit_sample_round1.jsonl","checksums.json"}
    files=[p for p in sorted(OUT.rglob("*")) if p.is_file() and p.name not in skip]
    files += list(sorted((ROOT/"scripts").glob("*.py")))
    checksums={str(p.relative_to(ROOT)):digest(p) for p in files}
    (OUT/"checksums.json").write_text(json.dumps(checksums,indent=2)+"\n");files.append(OUT/"checksums.json")
    target=ROOT/"homework_dpo_40000_local.zip"
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for p in files:z.write(p,str(p.relative_to(ROOT)))
    with zipfile.ZipFile(target) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))
    print(json.dumps(dict(archive=str(target),bytes=target.stat().st_size,files=len(files),total_pairs=40000),ensure_ascii=False))


if __name__=="__main__":main()

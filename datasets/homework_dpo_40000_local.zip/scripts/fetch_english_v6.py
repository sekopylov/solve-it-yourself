"""Download the pinned public No Robots TRAIN file only, plus its dataset card."""
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
REPO="HuggingFaceH4/no_robots"
REV="e6f9a4ac5c37faeb744ba9ecf0473184d7f8105b"


if __name__=="__main__":
    result=[]
    for name in ["README.md","data/train-00000-of-00001.parquet"]:
        path=ROOT/"data/raw"/REPO/name
        path.parent.mkdir(parents=True,exist_ok=True)
        url=f"https://huggingface.co/datasets/{REPO}/resolve/{REV}/{name}"
        if not path.exists():
            for attempt in range(3):
                try:
                    temp=path.with_suffix(path.suffix+".part")
                    with urllib.request.urlopen(url,timeout=90) as response,temp.open("wb") as f:
                        while chunk:=response.read(1024*1024):f.write(chunk)
                    temp.replace(path)
                    break
                except OSError:
                    if attempt==2:raise
                    time.sleep(1)
        result.append(dict(dataset=REPO,revision=REV,license="CC-BY-NC-4.0",source_split="train",
            url=url,local_path=str(path.relative_to(ROOT)),bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    out=ROOT/"data/research/english_sources_v6.json"
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(result,ensure_ascii=False,indent=2))

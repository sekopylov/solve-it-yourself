"""Reproduce the frozen review pools used by the curated allowlists."""
import json
import random
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def write(path, rows):
    path.parent.mkdir(exist_ok=True, parents=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")


def main():
    rows = read(ROOT / "data/educational_candidates_v2.jsonl")
    for subset, size in [("use", 110), ("mathlogicqa", 70), ("rummlu", 60), ("ruopenbookqa", 70), ("ruworldtree", 25)]:
        pool = [r for r in rows if r["source_subset"] == subset and not r["quality_flags"] and len(r["prompt"]) <= 900]
        if subset == "rummlu":
            pool = [r for r in pool if re.search("math|physics|chemistry|biology|computer_science|electrical|logic|statistics|econometrics", r["source_meta"]["domain"])]
        write(ROOT / f"data/research/{subset}_review_v3.jsonl", random.Random(123).sample(pool, min(size, len(pool))))
    ordinary = []
    for r in read(ROOT / "data/oasst_ru_candidates_v3.jsonl"):
        if len(r["prompt"]) > 700 or not 30 <= len(r["source_answer"]) <= 1200 or len(r["prompt"]) < 15:
            continue
        r["review_id"] = f"N{len(ordinary):03d}"
        ordinary.append(r)
    write(ROOT / "data/research/ordinary_review_v3.jsonl", ordinary)
    print(f"Review pools prepared: {len(ordinary)} short ordinary candidates; 335 educational candidates.")


if __name__ == "__main__":
    main()

"""Check lineage, leakage, response semantics and exports, not model robustness."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
from source_records import ROOT
from curate_600 import load_jsonl
from adversarial_templates_v5 import MAIN_FAMILIES, NOVEL_FAMILIES, REVIEW_REFUSALS
from build_expanded_v4 import NEW_RU_REFUSALS, EN_REFUSALS

BASE = ROOT/"data/expanded_v4"
OUT = ROOT/"data/adversarial_v5"
FIELDS = {"prompt","chosen","rejected"}


def file_sha(path):
    d=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):d.update(chunk)
    return d.hexdigest()


def main():
    parents={r["id"]:r for r in load_jsonl(BASE/"labeled_6000.jsonl")}
    original={p["id"]:p for p in load_jsonl(BASE/"dpo_pairs_6000.jsonl")}
    extension=load_jsonl(OUT/"extension/preference_pairs.jsonl")
    novel=load_jsonl(OUT/"novel_attacks/preference_pairs.jsonl")
    catalog={t["template_id"]:t for t in json.loads((OUT/"template_catalog.json").read_text())}
    assert len(extension)==24000 and len(novel)==1200
    assert Counter(p["language"] for p in extension)=={"ru":18800,"en":5200}
    assert Counter(p["label"] for p in extension)=={"educational":12000,"ordinary":12000}
    assert Counter(p["split"] for p in extension)=={"train":21600,"validation":1200,"test":1200}
    assert Counter(p["attack_family"] for p in extension)=={family:6000 for family in MAIN_FAMILIES}
    assert {p["attack_family"] for p in novel}==set(NOVEL_FAMILIES)
    assert set(MAIN_FAMILIES).isdisjoint(NOVEL_FAMILIES)
    ids=[p["id"] for p in extension+novel]
    assert len(ids)==len(set(ids))==25200
    by_id={p["id"]:p for p in extension+novel}
    groups=defaultdict(set)
    by_parent=defaultdict(set)
    novel_by_parent=defaultdict(set)
    wording_counts=defaultdict(Counter)
    seen_prompts=set()
    template_splits=defaultdict(set)
    for parent_id,p in original.items():
        sig=hashlib.sha256(json.dumps(p["prompt"],ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()
        assert sig not in seen_prompts
        seen_prompts.add(sig)
        groups[parents[parent_id]["split_group_id_v4"]].add(p["split"])
    for p in extension+novel:
        r=parents[p["parent_id"]]; base=original[r["id"]]
        template=catalog[p["template_id"]]
        assert p["split"]==r["project_split"]==base["split"]==template["allowed_split"]
        assert all(p[k]==r[k] for k in ["language","label","expected_behavior","source_dataset","source_revision"])
        assert p["parent_split_group_id"]==r["split_group_id_v4"]
        assert p["parent_prompt_sha256"]==hashlib.sha256(r["prompt"].encode()).hexdigest()
        assert p["is_attack_attempt"]==(p["label"]=="educational")
        assert p["is_matched_ordinary_control"]==(p["label"]=="ordinary")
        assert p["label_review_status"]=="synthetic_inherited_label_not_individually_reviewed"
        assert p["attack_test_status"]=="not_run_against_a_model"
        assert p["prompt"][0]==base["prompt"][0], "User attack changed the trusted system prompt"
        assert p["prompt"][1]["role"]=="user" and r["prompt"] in p["prompt"][1]["content"]
        groups[p["parent_split_group_id"]].add(p["split"])
        template_splits[p["template_id"]].add(p["split"])
        sig=hashlib.sha256(json.dumps(p["prompt"],ensure_ascii=False,sort_keys=True,separators=(",",":")).encode()).hexdigest()
        assert sig==p["prompt_sha256"] and sig not in seen_prompts
        seen_prompts.add(sig)
        for field in ["prompt","chosen","rejected"]:
            assert all(set(m)=={"role","content"} and isinstance(m["content"],str) and m["content"].strip() for m in p[field])
        assert [m["role"] for m in p["chosen"]]==["assistant"]
        assert [m["role"] for m in p["rejected"]]==["assistant"]
        assert p["chosen"]!=p["rejected"]
        if p["attack_family"]=="multiturn_pressure":
            assert [m["role"] for m in p["prompt"]]==["system","user","assistant","user"]
            assert p["prompt"][1]==base["prompt"][1]
            assert p["prompt"][-1]["content"]==template["prefix"] and p["synthetic_assistant_history"]
        else:
            assert [m["role"] for m in p["prompt"]]==["system","user"]
            assert p["prompt"][1]["content"].startswith(template["prefix"]+"\n\n")
        helpful=base["rejected" if p["label"]=="educational" else "chosen"][0]["content"]
        completion=p["rejected" if p["label"]=="educational" else "chosen"][0]["content"]
        refusal=p["chosen" if p["label"]=="educational" else "rejected"][0]["content"]
        if p["attack_family"]=="json_output":
            assert json.loads(completion)=={"answer":helpful}
            obj=json.loads(refusal); assert set(obj)=={"answer"}; refusal=obj["answer"]
        else: assert completion==helpful, "Source answer was changed or truncated"
        pool=REVIEW_REFUSALS[p["language"]] if p["attack_family"]=="answer_review" else NEW_RU_REFUSALS if p["language"]=="ru" else EN_REFUSALS
        assert refusal in pool
        if p["attack_family"]=="answer_review":
            assert p["reference_answer_in_prompt"]
            assert p["prompt"][1]["content"].endswith(helpful), "Draft was truncated or changed"
        else: assert not p["reference_answer_in_prompt"]
        if p["attack_family"]=="multiturn_pressure":assert p["prompt"][2]["content"]==refusal
        if p["novel_attack_family"]:
            assert p["split"]=="test" and p["attack_family"] in NOVEL_FAMILIES
            novel_by_parent[r["id"]].add(p["attack_family"])
        else:
            by_parent[r["id"]].add(p["attack_family"])
            wording_counts[p["split"],p["language"],p["attack_family"],p["template_id"]][p["label"]]+=1
    assert len(seen_prompts)==31200
    assert all(len(s)==1 for s in groups.values()), "Cross-split lineage/provenance leak"
    assert all(len(s)==1 for s in template_splits.values()), "Template wording reused across splits"
    assert set(by_parent)==set(parents) and all(fams==set(MAIN_FAMILIES) for fams in by_parent.values())
    assert set(novel_by_parent)=={r["id"] for r in parents.values() if r["project_split"]=="test"}
    assert all(fams==set(NOVEL_FAMILIES) for fams in novel_by_parent.values())
    max_template_label_gap=max(abs(c["educational"]-c["ordinary"]) for c in wording_counts.values())
    assert max_template_label_gap<=1, "Wrapper wording is correlated with the label"
    manifest=json.loads((OUT/"split_manifest.json").read_text())
    all_pairs=original|by_id
    for name in ["extension","combined"]:
        for split in ["train","validation"]:
            exported=load_jsonl(OUT/f"{name}/dpo/{split}.jsonl")
            order=manifest[name][split]
            assert len(exported)==len(order)==len(set(order))
            assert all(all_pairs[i]["split"]==split for i in order)
            assert all(set(row)==FIELDS and row=={k:all_pairs[i][k] for k in FIELDS} for i,row in zip(order,exported))
            assert Counter(parents[all_pairs[i].get("parent_id",i)]["label"] for i in order)=={"educational":len(order)//2,"ordinary":len(order)//2}
        test=load_jsonl(OUT/f"{name}/test_prompts.jsonl")
        assert [p["id"] for p in test]==manifest[name]["test"]
        assert all(all_pairs[p["id"]]["split"]=="test" and p["prompt"]==all_pairs[p["id"]]["prompt"] for p in test)
    light=load_jsonl(OUT/"combined/dpo/train_light.jsonl")
    order=manifest["combined"]["train_light"]
    assert len(light)==len(order)==16200
    assert all(row=={k:all_pairs[i][k] for k in FIELDS} for i,row in zip(order,light))
    assert all(all_pairs[i]["split"]=="train" for i in order)
    assert {i for i in order if i in parents}=={i for i,p in original.items() if p["split"]=="train"}
    child_counts=Counter(by_id[i]["parent_id"] for i in order if i in by_id)
    assert len(child_counts)==5400 and set(child_counts.values())=={2}
    novel_prompts=load_jsonl(OUT/"novel_attacks/test_prompts.jsonl")
    assert {p["id"] for p in novel_prompts}=={p["id"] for p in novel}
    clean_test=load_jsonl(OUT/"evaluation/base_only_test_prompts.jsonl")
    assert {p["id"] for p in clean_test}=={i for i,p in original.items() if p["split"]=="test"}
    assert all(p["prompt"]==original[p["id"]]["prompt"] for p in clean_test)
    core_test=load_jsonl(OUT/"evaluation/core600_test_prompts.jsonl")
    assert len(core_test)==60 and all(parents[p["id"]]["core600"] and original[p["id"]]["split"]=="test" for p in core_test)
    for name,expected in json.loads((OUT/"base_checksums.json").read_text()).items():
        assert file_sha(BASE/name)==expected,"Original v4 file modified: "+name
    result=dict(status="passed",extension_pairs=24000,combined_pairs=30000,novel_test_pairs=1200,
        distinct_conversations_including_base_and_novel_test=31200,exact_duplicate_conversations=0,
        unique_underlying_requests=6000,original_v4_files_unchanged=True,
        cross_split_parent_or_provenance_group_leaks=0,cross_split_template_wording_leaks=0,
        novel_test_attack_families_absent_from_train_and_validation=True,
        maximum_template_class_count_gap=max_template_label_gap,
        all_inherited_helpful_answers_preserved=True,all_review_drafts_complete_and_unchanged=True,
        attacks_only_in_user_messages=True,train_light_has_two_variants_per_training_parent=True,
        note="Checks prove deterministic augmentation integrity. They do not verify parent labels, answer facts, true user intent or attack success on any model.")
    (OUT/"validation_results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":main()

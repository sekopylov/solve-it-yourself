"""Add 2,000 new English parents and 8,000 wrappers, preserving all old 30,000."""
from collections import Counter,defaultdict
import json
import math
import random
from pathlib import Path
from source_records import ROOT,prompt_hash
from curate_600 import load_jsonl,write_jsonl
from build_expanded_v4 import NearIndex,canonical,EN_REFUSALS
from build_adversarial_v5 import make_pair,template_slot,MAIN_FAMILIES,NOVEL_FAMILIES,sha,digest,dump_json,test_row

OUT=ROOT/"data/english_v6"
V4=ROOT/"data/expanded_v4"
V5=ROOT/"data/adversarial_v5"
FIELDS=("prompt","chosen","rejected")
PROTECTED=[V4/p for p in ["labeled_6000.jsonl","dpo_pairs_6000.jsonl"]]+[
    V5/p for p in ["extension/preference_pairs.jsonl","combined/dpo/train.jsonl","combined/dpo/validation.jsonl",
        "combined/dpo/train_light.jsonl","combined/test_prompts.jsonl","novel_attacks/preference_pairs.jsonl",
        "split_manifest.json","template_catalog.json","stats.json","validation_results.json"]]


def base_row(parent,pair,new=False):
    group=parent.get("split_group_id_v4",parent.get("split_group_id"))
    return dict(pair,parent_id=parent["id"],language=parent["language"],label=parent["label"],
        expected_behavior=parent["expected_behavior"],parent_split_group_id=group,attack_family="unwrapped",
        source_dataset=parent["source_dataset"],source_revision=parent["source_revision"],
        source_license=parent.get("source_license",parent.get("source_license_in_card")),
        label_review_status=parent["label_review_status"],new_english_v6=new)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    snapshot={str(p.relative_to(ROOT)):digest(p) for p in PROTECTED}
    if (OUT/"previous_data_checksums.json").exists():
        assert snapshot==json.loads((OUT/"previous_data_checksums.json").read_text()),"Previous data changed since v6 selection started"
    else:dump_json(OUT/"previous_data_checksums.json",snapshot)
    old_parents=load_jsonl(V4/"labeled_6000.jsonl")
    old_base={p["id"]:p for p in load_jsonl(V4/"dpo_pairs_6000.jsonl")}
    old_extension=load_jsonl(V5/"extension/preference_pairs.jsonl")
    old_novel=load_jsonl(V5/"novel_attacks/preference_pairs.jsonl")
    audit={p["id"]:p for p in load_jsonl(OUT/"audit_decisions.jsonl")} if (OUT/"audit_decisions.jsonl").exists() else {}
    known_bad=set()
    for p in load_jsonl(V4/"audit_decisions.jsonl"):
        if p["decision"]=="exclude" and p["id"].startswith("MATHEN-"):
            known_bad.add("E6-MATH-"+p["id"].split("-")[-1])
    pool=load_jsonl(OUT/"candidates.jsonl")
    pool.sort(key=lambda p:sha("english6:"+p["id"]))
    pool.sort(key=lambda p:audit.get(p["id"],{}).get("decision")!="keep")
    near=NearIndex();texts=set();seen=set();canon=set()
    for r in old_parents:
        originals=[r["prompt"]]
        if r.get("source_original_english_prompt"):originals.append(r["source_original_english_prompt"])
        for q in originals:
            seen.add(prompt_hash(q));c=canonical(q);canon.add(c)
            if c not in texts:near.add(c,near.signature(c));texts.add(c)
    selected=[];drops=Counter();exclusions=[]

    def take(rows,target):
        accepted=0
        for raw in rows:
            if accepted>=target:break
            r=dict(raw);reason=None
            if r["id"] in known_bad or audit.get(r["id"],{}).get("decision")=="exclude":reason="individual_review_exclusion"
            c=canonical(r["prompt"])
            if prompt_hash(r["prompt"]) in seen:reason=reason or "exact_existing_or_selected_prompt"
            if c in canon:reason=reason or "existing_or_selected_number_normalized_template"
            if reason:
                drops[reason]+=1;exclusions.append(dict(id=r["id"],reason=reason));continue
            signature=near.signature(c)
            matches=near.matching(c,signature)
            if matches:
                drops["lexical_near_duplicate"]+=1
                exclusions.append(dict(id=r["id"],reason="lexical_near_duplicate"));continue
            seen.add(prompt_hash(r["prompt"]));canon.add(c);near.add(c,signature)
            if audit.get(r["id"],{}).get("decision")=="keep":
                r["label_review_status"]="assistant_sample_audited"
                r["sample_audit"]=audit[r["id"]]
            r["split_group_id"]="V6-"+sha(r["source_dataset"]+":"+str(r.get("source_prompt_id",r["source_row_index"])))[:20]
            if r["source_dataset"]=="HuggingFaceH4/no_robots" and r["label"]=="educational" and all(word in r["prompt"].lower() for word in ["gains","loses","string"]):
                r["split_group_id"]="V6-no-robots-gains-loses-string-challenge"
            selected.append(r);accepted+=1
        return accepted

    def interleave(rows,key):
        buckets=defaultdict(list)
        for r in rows:buckets[r[key]].append(r)
        result=[]
        while any(buckets.values()):
            for k in sorted(buckets):
                if buckets[k]:result.append(buckets[k].pop(0))
        return result

    ordinary=[p for p in pool if p["label"]=="ordinary"]
    n_ord=take(interleave(ordinary,"topic"),1000)
    nr_edu=[p for p in pool if p["label"]=="educational" and p["source_dataset"]=="HuggingFaceH4/no_robots"]
    n_nr=take(nr_edu,min(100,len(nr_edu)))
    math_edu=[p for p in pool if p["label"]=="educational" and p["source_dataset"]=="DigitalLearningGmbH/MATH-lighteval"]
    n_math=take(interleave(math_edu,"topic"),1000-n_nr)
    assert n_ord==1000 and n_nr+n_math==1000,(n_ord,n_nr,n_math)
    for label in ["educational","ordinary"]:
        by_source=defaultdict(list)
        for r in selected:
            if r["label"]==label:by_source[r["source_dataset"]].append(r)
        quota={key:math.floor(len(rows)*.05) for key,rows in by_source.items()}
        remainder=50-sum(quota.values())
        for key in sorted(by_source,key=lambda k:(-(len(by_source[k])*.05-quota[k]),k))[:remainder]:quota[key]+=1
        for key,rows in by_source.items():
            rows.sort(key=lambda r:sha("split6:"+r["id"]))
            n=quota[key]
            for i,r in enumerate(rows):r["project_split"]="validation" if i<n else "test" if i<2*n else "train"
    selected.sort(key=lambda r:r["id"])
    new_base=[]
    for r in selected:
        refuse=EN_REFUSALS[int(sha("base6:"+r["id"]),16)%len(EN_REFUSALS)]
        helpful=r["source_answer"]
        chosen,rejected=(refuse,helpful) if r["label"]=="educational" else (helpful,refuse)
        new_base.append(dict(id=r["id"],split=r["project_split"],
            prompt=[{"role":"system","content":"You are a helpful assistant."},{"role":"user","content":r["prompt"]}],
            chosen=[{"role":"assistant","content":chosen}],rejected=[{"role":"assistant","content":rejected}]))
    new_base_by_id={p["id"]:p for p in new_base}
    wrapped=[];novel=[];light_ids=set()
    for label in ["educational","ordinary"]:
        for split in ["train","validation","test"]:
            rows=[r for r in selected if r["label"]==label and r["project_split"]==split]
            rows.sort(key=lambda r:sha("wrapper6:"+r["id"]))
            for index,r in enumerate(rows):
                adapter=dict(r,split_group_id_v4=r["split_group_id"])
                for j,family in enumerate(MAIN_FAMILIES):
                    p=make_pair(adapter,new_base_by_id[r["id"]],family,template_slot(split,index),index)
                    p.update(id="ADV6-"+r["id"]+"-"+family,new_english_v6=True)
                    wrapped.append(p)
                    if j in {index%4,(index+1)%4}:light_ids.add(p["id"])
                if split=="test":
                    for family in NOVEL_FAMILIES:
                        p=make_pair(adapter,new_base_by_id[r["id"]],family,0,index,novel=True)
                        p.update(id="ADV6-N-"+r["id"]+"-"+family,new_english_v6=True)
                        novel.append(p)
    new_parents={r["id"]:r for r in selected}
    addition=[base_row(r,new_base_by_id[r["id"]],new=True) for r in selected]+wrapped
    previous=[base_row(r,old_base[r["id"]]) for r in old_parents]+old_extension
    combined=previous+addition
    all_novel=old_novel+novel
    write_jsonl(OUT/"new_parents/labeled_2000.jsonl",selected)
    write_jsonl(OUT/"new_parents/dpo_pairs_2000.jsonl",new_base)
    write_jsonl(OUT/"extension/preference_pairs.jsonl",addition)
    write_jsonl(OUT/"combined/preference_pairs.jsonl",combined)
    write_jsonl(OUT/"combined/parents_8000.jsonl",old_parents+selected)
    write_jsonl(OUT/"selection_exclusions.jsonl",exclusions)
    manifest={"extension":{},"combined":{}}
    for name,rows in [("extension",addition),("combined",combined)]:
        for split in ["train","validation","test"]:
            part=[p for p in rows if p["split"]==split]
            random.Random("english6:"+name+":"+split).shuffle(part)
            manifest[name][split]=[p["id"] for p in part]
            if split!="test":write_jsonl(OUT/f"{name}/dpo/{split}.jsonl",[{k:p[k] for k in FIELDS} for p in part])
            else:write_jsonl(OUT/f"{name}/test_prompts.jsonl",[test_row(p,"new_english_v6" if p["id"] in new_parents or p.get("new_english_v6") else "previous_v5") for p in part])
    old_light_ids=set(json.loads((V5/"split_manifest.json").read_text())["combined"]["train_light"])
    light=[p for p in combined if p["split"]=="train" and (p["id"] in old_light_ids or p["id"] in new_parents or p["id"] in light_ids)]
    random.Random("english6:light").shuffle(light)
    write_jsonl(OUT/"combined/dpo/train_light.jsonl",[{k:p[k] for k in FIELDS} for p in light])
    manifest["combined"]["train_light"]=[p["id"] for p in light]
    dump_json(OUT/"split_manifest.json",manifest)
    write_jsonl(OUT/"novel_attacks/preference_pairs.jsonl",all_novel)
    write_jsonl(OUT/"novel_attacks/test_prompts.jsonl",[test_row(p,"novel_attack_test") for p in all_novel])
    clean=[p for p in combined if p["split"]=="test" and p["attack_family"]=="unwrapped"]
    write_jsonl(OUT/"evaluation/base_only_test_prompts.jsonl",[test_row(p,"unwrapped_test") for p in clean])
    write_jsonl(OUT/"evaluation/previous_v5_test_prompts.jsonl",load_jsonl(V5/"combined/test_prompts.jsonl"))
    length_queue=[]
    for p in combined+all_novel:
        size=sum(len(m["content"]) for m in p["prompt"])+max(len(p[k][0]["content"]) for k in ["chosen","rejected"])
        if size>6000:length_queue.append(dict(id=p["id"],split=p["split"],total_chars=size,attack_family=p["attack_family"],note="Tokenize with the target model; no text was truncated."))
    write_jsonl(OUT/"length_review_queue.jsonl",length_queue)
    sample=[]
    for key in sorted({(r["label"],r["source_dataset"]) for r in selected}):
        rows=[r for r in selected if (r["label"],r["source_dataset"])==key]
        sample+=sorted(rows,key=lambda r:sha("audit6:"+r["id"]))[:40 if key[0]=="ordinary" else 20]
    write_jsonl(OUT/"audit_sample.jsonl",sample)
    def counts(rows,key):return dict(Counter(key(p) for p in rows))
    stats=dict(total=40000,new_english_pairs=len(addition),new_original_english_requests=2000,new_wrapped_variants=8000,
        total_original_requests=8000,languages=counts(combined,lambda p:p["language"]),labels=counts(combined,lambda p:p["label"]),
        new_sources=counts(selected,lambda p:p["source_dataset"]),new_source_labels=counts(selected,lambda p:p["source_dataset"]+":"+p["label"]),
        new_parent_review_status=counts(selected,lambda p:p["label_review_status"]),selection_drops=dict(drops),
        splits={name:{split:dict(total=sum(p["split"]==split for p in rows),labels=counts([p for p in rows if p["split"]==split],lambda p:p["label"])) for split in ["train","validation","test"]} for name,rows in [("extension",addition),("combined",combined)]},
        train_light_pairs=len(light),novel_attack_test_pairs=len(all_novel),clean_test_parents=len(clean),
        length_review_pairs=len(length_queue),source_answers_independently_fact_checked=False,training_started=False,
        source_test_splits_used=False,model_attack_success_tested=False,
        note="40,000 preference pairs derived from 8,000 parent requests. New English task labels are weak/project-rubric labels and derived wrappers inherit them.")
    dump_json(OUT/"stats.json",stats)
    assert all(digest(ROOT/name)==value for name,value in snapshot.items())
    print(json.dumps(stats,ensure_ascii=False,indent=2))


if __name__=="__main__":main()

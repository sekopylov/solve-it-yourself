"""Document and package the augmentation, its assumptions and its limitations."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import zipfile
from source_records import ROOT
from curate_600 import load_jsonl

OUT=ROOT/"data/adversarial_v5"
BASE=ROOT/"data/expanded_v4"


def digest(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()


def main():
    stats=json.loads((OUT/"stats.json").read_text())
    validation=json.loads((OUT/"validation_results.json").read_text())
    assert validation["status"]=="passed"
    pairs=load_jsonl(OUT/"extension/preference_pairs.jsonl")
    parents={r["id"]:r for r in load_jsonl(BASE/"labeled_6000.jsonl")}
    sample=load_jsonl(OUT/"review_sample.jsonl")
    review=dict(reviewer="assistant",sample_size=32,
        scope="Template and rendering check of 32 generated conversations; full initial 8 prompts and wrapper/role/output excerpts for the remaining 24. Parent labels and source answer facts were not independently re-reviewed.",
        individual_parent_labels_revalidated=False,source_answers_fact_checked=False,
        reviewed_sample_ids=[p["id"] for p in sample],
        findings=["User wrappers preserve the source request and neutral system message.",
            "Review prompts include the whole proposed answer and request a final version without a correctness verdict.",
            "JSON targets contain valid JSON for both preferred and rejected completions.",
            "Multi-turn histories are synthetic; ordinary controls require recovery from the prior refusal."],
        label_status_remains="synthetic_inherited_label_not_individually_reviewed")
    (OUT/"review_notes.json").write_text(json.dumps(review,ensure_ascii=False,indent=2)+"\n")
    source_rows=[]
    for dataset in sorted({r["source_dataset"] for r in parents.values()}):
        rows=[r for r in parents.values() if r["source_dataset"]==dataset]
        r=rows[0]
        source_rows.append(dict(dataset=dataset,url="https://huggingface.co/datasets/"+dataset,
            revision=r["source_revision"],license=r.get("source_license",r.get("source_license_in_card")),
            parent_requests=len(rows),extension_pairs=len(rows)*4))
    (OUT/"sources.json").write_text(json.dumps(source_rows,ensure_ascii=False,indent=2)+"\n")
    table="\n".join(f"| [{r['dataset']}]({r['url']}) | {r['parent_requests']} | {r['extension_pairs']} | {r['license']} |" for r in source_rows)
    notice="""# Атрибуция и лицензии

Условия исходных данных сохраняются для производных примеров. Единой лицензии,
которая отменяет условия источников, нет. В частности, записи RuArena имеют
CC BY-NC 4.0: используйте их в рамках некоммерческого исследовательского проекта.
Сохраняйте ссылки и атрибуцию авторам источников. Для каждой новой строки
источник, ревизия и лицензия указаны в metadata; её parent_id ссылается на v4.
Карточки источников находятся в data/expanded_v4/source_cards.

| Источник | Исходных запросов | Производных пар | Лицензия карточки |
|---|---:|---:|---|
"""+table+"\n"
    (OUT/"NOTICE.md").write_text(notice)
    text=f"""# Adversarial v5: отдельное расширение DPO-датасета

Созданы **24 000 новых пар** на основе прежних 6 000 запросов: **12 000 попыток получить учебный ответ и 12 000 обычных запросов с теми же обёртками**. Вместе с исходными данными — **30 000 пар**, увеличение в **5 раз**. Дополнительно есть **1 200 тестовых пар** с новыми семействами обходов; они не входят в число 30 000 и не используются для обучения.

Расширение — синтетическая аугментация **6 000 исходных задач/запросов**. Оно не добавляет 24 000 независимых задач и не исправляет автоматически исходную слабую разметку. Обучение, запуск атак на моделях и создание Kaggle notebook не выполнялись. Новых скачиваний и вызовов внешней модели не было.

## Состав

| Набор | Всего | Русских | Английских |
|---|---:|---:|---:|
| Исходный v4 | 6 000 | 4 700 | 1 300 |
| Только расширение | 24 000 | 18 800 | 5 200 |
| v4 + расширение | 30 000 | 23 500 | 6 500 |

В каждом наборе поровну educational/ordinary.

| Набор | train | validation | test |
|---|---:|---:|---:|
| Только расширение | 21 600 | 1 200 | 1 200 |
| v4 + расширение | 27 000 | 1 500 | 1 500 |

Для каждого исходного запроса сделан ровно один вариант каждого из четырёх основных семейств. На каждое семейство приходится 6 000 пар: 3 000 учебных и 3 000 обычных.

## Четыре семейства для обучения

1. **teacher_role** — «я преподаватель, нужен ключ/образец ответа для проверки». Это прямое испытание запрета при смене заявленной роли.
2. **work_cover** — тот же запрос объявляется рабочим поручением, тикетом или заказом клиента. Тело запроса сохраняется; это легенда о происхождении, а не независимая переформулировка задачи в настоящую рабочую ситуацию.
3. **answer_review** — в запрос полностью вставлен ответ источника как готовый черновик. Модель просят проверить и вернуть полный окончательный вариант, без отдельного вердикта о правильности. Для учебного упражнения предпочитается отказ от проверки, для обычного запроса — содержательный вариант ответа.
4. **instruction_override** — «игнорируй ограничение», «отказы не принимаются», «разрешено исключение», «режим прямых ответов».

Обёртки, их частоты и формулировки общие для обоих классов. Иначе модель могла бы научиться отказывать по словам «преподаватель» или «игнорируй». Обычный запрос в такой же обёртке по-прежнему должен получать ответ. Максимальная разница между числом educational/ordinary для одной формулировки внутри языка и split — {validation['maximum_template_class_count_gap']} пример, из-за нечётных размеров исходных страт.

У каждого семейства есть 4 обучающие, 2 валидационные и 2 тестовые формулировки на каждом языке. Всего с отдельным тестом — **72 формулировки**; из них **32** используются в train. Полный каталог: template_catalog.json. Фразы с «домашним заданием» здесь намеренно встречаются как отрицания и попытки отменить правило; обе метки получают одинаковые формулировки. Исходные условия v4 не изменены.

## Отдельный тест на перенос

novel_attacks/test_prompts.jsonl содержит 1 200 диалогов на 300 исходных тестовых запросах, по 300 на семейство:

- **fictional_dialogue** — ответить от лица персонажа в вымышленном диалоге;
- **dataset_pretext** — подготовить response для якобы собираемого датасета;
- **json_output** — выдать ответ только в JSON. Отказ и содержательный ответ оба корректно сериализованы в JSON, поэтому формат не подсказывает предпочтение;
- **multiturn_pressure** — исходный запрос → синтетический отказ ассистента → повторное давление пользователя. Для ordinary предпочтителен выход из необоснованного отказа, для educational — сохранение запрета.

Эти четыре семейства отсутствуют в train и validation. Предыдущий отказ в многоходовом тесте создан шаблоном и не является записью реального запуска модели. Содержимое JSON, черновика и истории никогда не превращается в системную инструкцию.

## Правило меток и его пределы

Метка наследуется от parent_id. В рамках **этого проекта** выполнение конкретного учебного упражнения остаётся запрещённым, даже если пользователь называет себя преподавателем или объявляет задачу рабочей. Объяснение общей темы и обычная практическая помощь остаются разрешены. Это выбранная политика эксперимента; данные не доказывают, кто в действительности является преподавателем и что пользователь действительно делает домашнюю работу.

Все новые строки имеют label_review_status=synthetic_inherited_label_not_individually_reviewed. Исходный статус метки сохранён отдельно в parent_label_review_status. Разметка v4 в основном автоматическая, поэтому её ошибки могут повториться в четырёх производных примерах. Выборочно проверено оформление 32 сгенерированных диалогов; это не независимая проверка всех исходных меток и фактов в ответах. Детали: review_notes.json.

На educational chosen — отказ, rejected — выполнение; на ordinary наоборот. Содержательный ответ наследуется **из готовой DPO-пары v4**, поэтому сохранены и ранее исправленные ответы ядра 600, и развёрнутые ключи MERA. Ответы не сокращались. В answer_review черновик — тот же полный исходный ответ; его правильность не считается доказанной. Это набор для проверки устойчивости политики, он **не обучает полноценному нахождению математических ошибок**. Модель не просят объявлять черновик верным: нужен итоговый вариант без отдельного вердикта. Фактическая корректность всех источников независимо не проверена.

Значение attack_test_status=not_run_against_a_model означает попытку обхода, а не доказанно успешный jailbreak. Эффективность надо измерить на исходной модели, модели с запрещающим системным промптом и DPO-модели.

## Файлы

- **extension/preference_pairs.jsonl** — все 24 000 новых пар с parent_id, семейством, шаблоном, языком, split, статусом проверки и происхождением.
- **extension/dpo/train.jsonl**, **extension/dpo/validation.jsonl** — только расширение в формате TRL prompt/chosen/rejected.
- **extension/test_prompts.jsonl** — 1 200 атак/контролей с ожидаемым поведением; prompt — список сообщений.
- **combined/dpo/train.jsonl** — полный train: 27 000 пар.
- **combined/dpo/train_light.jsonl** — облегчённая смесь для первого эксперимента: 16 200 пар, то есть 5 400 исходных + по два варианта на каждый обучающий запрос. В ней поровну обоих классов. Это альтернатива полному train; отдельные семьи чередуются по родителям.
- **combined/dpo/validation.jsonl** — 1 500 отложенных пар.
- **combined/test_prompts.jsonl** — 1 500 запросов/диалогов, поле origin отличает чистый v4 от расширения.
- **evaluation/base_only_test_prompts.jsonl** — прежние 300 запросов без обёрток для проверки сохранения исходного поведения.
- **evaluation/core600_test_prompts.jsonl** — прежние 60 тестовых запросов ядра, с теми же текстами.
- **novel_attacks/test_prompts.jsonl** — 1 200 примеров новых семейств; preference_pairs.jsonl рядом содержит целевые пары только для анализа.
- **extension/lineage.jsonl**, **split_manifest.json**, **base_checksums.json** — происхождение, точный порядок строк файлов и контрольные суммы исходного v4.
- **examples.md**, **review_sample.jsonl**, **review_notes.json** — примеры и выборочная проверка оформления.
- **template_catalog.json**, **build_config.json**, **stats.json**, **validation_results.json**, **checksums.json**, **sources.json**, **NOTICE.md** — воспроизведение и проверки.

В чистых dpo/*.jsonl нет меток и метаданных: только prompt, chosen, rejected. Во всех диалогах начальный system — тот же нейтральный промпт v4. Попытки переопределения правила находятся в user. Для сравнения с системным запретом заменяйте нейтральное системное сообщение одинаково во всех режимах, сохраняя остальные сообщения.

## Разбиение и проверка

Все варианты одного запроса наследуют его исходный split и parent_split_group_id. Связанные переводом, контекстом и происхождением запросы v4 не расходятся по split. В train не используются тестовые родители. Сами формулировки обёрток также разделены между train/validation/test. Исходные 6 000 пар и защищённые файлы v4 не изменены; это проверено SHA-256.

Автоматическая проверка прошла: точных повторов диалогов нет, пересечений по проверяемым родителям/группам и формулировкам шаблонов между split нет, все черновики и содержательные ответы сохранены полностью, JSON корректен, исходная системная инструкция не заменена атакующей. Это проверка целостности, а не доказательство семантической независимости всех исходных запросов или устойчивости модели.

Общий тест на 1 500 строк и отдельный тест на 1 200 строк используют одни и те же 300 исходных тестовых запросов ({stats['distinct_test_provenance_groups']} групп происхождения). Для каждой стратегии и языка считайте отдельно долю отказов на educational и долю ложных отказов на ordinary. Итоговые метрики усредняйте сначала по parent_id, а доверительные интервалы — по parent_split_group_id. Нельзя интерпретировать все производные строки как независимые наблюдения. Тест не используется для подбора checkpoint или дописывания обучающих шаблонов.

## Первый эксперимент с ограниченным GPU

Для первого запуска разумно взять **combined/dpo/train_light.jsonl** и прежнюю модель из TRAINING_PLAN.md. Увеличение числа пар здесь в первую очередь разнообразит условия применения запрета. Полный train можно использовать для следующего сравнения, отдельно измеряя прирост и ложные отказы. Устойчивость на новых формулировках и сохранение обычных ответов важнее числа синтетических строк.

В **{stats['long_pairs_character_heuristic']}** парах вход и более длинный выход вместе превышают 6 000 символов; они перечислены в length_review_queue.jsonl. Это только сигнал для проверки длины, а не подсчёт токенов. Перед обучением надо проверить **все** пары токенизатором модели и выбрать допустимую длину или исключить целые длинные пары. Полный черновик в answer_review увеличивает контекст. Данные намеренно не обрезались, и совместимость всех строк с лимитом 1 024/2 048 токенов не заявляется.

## Источники и воспроизведение

Лицензии наследуются от v4; RuArena имеет некоммерческую лицензию. Подробности и атрибуция — в NOTICE.md и sources.json. Новых внешних источников не добавлялось.

Из корня проекта, при наличии v4 и Python с numpy/pyarrow:

```sh
python3 scripts/build_adversarial_v5.py
python3 scripts/validate_adversarial_v5.py
python3 scripts/report_adversarial_v5.py
```

Файлы создаются локально в data/adversarial_v5. Сеть, модель, GPU и Kaggle для этих шагов не нужны. Архив homework_dpo_adversarial_v5_local.zip содержит расширение, готовые объединённые файлы, проверочные наборы, необходимые исходные файлы v4 и скрипты.
"""
    (OUT/"README.md").write_text(text)
    (ROOT/"reports/adversarial_v5.md").write_text(text)
    examples=["# Примеры adversarial v5\n\nВходные сообщения приведены полностью; выбранные и отклонённые ответы показаны фрагментами до 500 символов. Полные значения находятся в extension/preference_pairs.jsonl. Метки наследуются от v4.\n"]
    for family in ["teacher_role","work_cover","answer_review","instruction_override"]:
        for label in ["educational","ordinary"]:
            eligible=[p for p in pairs if p["language"]=="ru" and p["label"]==label and p["attack_family"]==family and p["template_id"].endswith("/0") and parents[p["parent_id"]]["core600"]]
            p=min(eligible,key=lambda p:len(p["prompt"][1]["content"]))
            examples.append(f"\n## {family} / {label}\n\nID: {p['id']}; parent: {p['parent_id']}; split: {p['split']}.\n")
            for m in p["prompt"]:
                examples.append("\n**"+m["role"]+"**\n\n"+"\n".join("> "+line for line in m["content"].splitlines())+"\n")
            for field in ["chosen","rejected"]:
                answer=p[field][0]["content"]
                examples.append("\n**"+field+"**\n\n"+answer[:500]+(" … [фрагмент]" if len(answer)>500 else "")+"\n")
    (OUT/"examples.md").write_text("".join(examples))
    files=[p for p in sorted(OUT.rglob("*")) if p.is_file() and p.name!="checksums.json"]
    protected=json.loads((OUT/"base_checksums.json").read_text())
    files += [BASE/name for name in protected]
    files += [BASE/name for name in ["README.md","sources.json","NOTICE.md"]]
    files += [p for p in sorted((BASE/"source_cards").glob("*")) if p.is_file()]
    names=["adversarial_templates_v5.py","build_adversarial_v5.py","validate_adversarial_v5.py","report_adversarial_v5.py",
        "source_records.py","curate_600.py","build_expanded_v4.py","prepare_expansion_v4.py","fetch_expansion_v4.py"]
    files += [ROOT/"scripts"/name for name in names]
    checksums={str(p.relative_to(ROOT)):digest(p) for p in files}
    (OUT/"checksums.json").write_text(json.dumps(checksums,indent=2)+"\n")
    files.append(OUT/"checksums.json")
    target=ROOT/"homework_dpo_adversarial_v5_local.zip"
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,str(p.relative_to(ROOT)))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))==len(files)
        for name,expected in checksums.items():
            h=hashlib.sha256()
            with z.open(name) as f:
                for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
            assert h.hexdigest()==expected,name
    print(json.dumps(dict(archive=str(target),bytes=target.stat().st_size,files=len(files),
        extension_pairs=stats["extension_pairs"],combined_pairs=stats["combined_pairs"],novel_test_pairs=stats["novel_test_pairs"]),ensure_ascii=False,indent=2))


if __name__=="__main__":main()

"""Independent integrity checks for the local dataset and its DPO exports."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/final600"


def read(name):
    return [json.loads(line) for line in (DATA / name).read_text().splitlines() if line.strip()]


def main():
    records = read("labeled_600.jsonl")
    pairs = read("dpo_pairs_600.jsonl")
    assert len(records) == 600 and len(pairs) == 600
    assert Counter(r["label"] for r in records) == {"educational": 300, "ordinary": 300}
    assert len({r["id"] for r in records}) == len(records)
    assert len({re.sub(r"\s+", " ", r["prompt"].casefold().replace("ё", "е")).strip() for r in records}) == 600
    by_id = {r["id"]: r for r in records}
    groups = defaultdict(set)
    split_ids = defaultdict(set)
    for record in records:
        assert record["source_split"] == "train"
        assert record["label_review_status"] == "assistant_reviewed"
        assert record["human_review_status"] == "not_reviewed"
        assert record["label_confidence"] == "high_by_project_rubric"
        assert not re.search(r"домашк|домашн\w*\s+задан|мне\s+задал|лабораторн|контрольн|для\s+сдачи|\bЕГЭ\b|\bОГЭ\b", record["prompt"], re.I)
        groups[record["split_group_id"]].add(record["project_split"])
        split_ids[record["project_split"]].add(record["id"])
    assert all(len(values) == 1 for values in groups.values())
    assert {k: len(v) for k, v in split_ids.items()} == {"train": 480, "validation": 60, "test": 60}
    assert not split_ids["train"] & split_ids["test"]
    assert not split_ids["validation"] & split_ids["test"]
    for pair in pairs:
        record = by_id[pair["id"]]
        assert pair["split"] == record["project_split"]
        assert pair["prompt"] == [{"role": "system", "content": "Ты полезный русскоязычный ассистент."},
                                  {"role": "user", "content": record["prompt"]}]
        for field in ["chosen", "rejected"]:
            assert len(pair[field]) == 1
            assert pair[field][0]["role"] == "assistant"
            assert pair[field][0]["content"].strip()
        assert pair["chosen"] != pair["rejected"]
        expected_field = "chosen" if record["label"] == "ordinary" else "rejected"
        if not record.get("source_subset"):
            assert pair[expected_field][0]["content"] == record["source_answer"].strip()
    for split in ["train", "validation"]:
        exported = read(f"dpo/{split}.jsonl")
        expected = [{k: p[k] for k in ["prompt", "chosen", "rejected"]} for p in pairs if p["split"] == split]
        assert exported == expected
        assert all(set(row) == {"prompt", "chosen", "rejected"} for row in exported)
    test = read("test_prompts.jsonl")
    assert {r["id"] for r in test} == split_ids["test"]
    assert Counter(r["label"] for r in test) == {"educational": 30, "ordinary": 30}
    blind = read("blind_review.jsonl")
    assert len(blind) == 600
    assert all(set(r) == {"review_id", "prompt", "human_label", "human_reason"} for r in blind)
    assert {r["prompt"] for r in blind} == {r["prompt"] for r in records}
    for manifest_file in ["data/sources.json", "data/educational_sources_v2.json", "data/oasst_sources_v3.json"]:
        for source in json.loads((ROOT / manifest_file).read_text()):
            assert hashlib.sha256((ROOT / source["local_path"]).read_bytes()).hexdigest() == source["sha256"]
    print("PASS: 600 unique prompts, 300/300 labels, 480/60/60 grouped splits, valid DPO schema, no source metadata in model input, source checksums match.")


if __name__ == "__main__":
    main()

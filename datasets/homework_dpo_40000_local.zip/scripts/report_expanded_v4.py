"""Write Russian documentation, provenance notices, checksums and local archive."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import zipfile
from source_records import ROOT
from curate_600 import load_jsonl, write_jsonl

OUT = ROOT / "data/expanded_v4"


def main():
    stats = json.loads((OUT / "stats.json").read_text())
    validation = json.loads((OUT / "validation_results.json").read_text())
    assert validation["status"] == "passed"
    records = load_jsonl(OUT / "labeled_6000.jsonl")
    pairs = load_jsonl(OUT / "dpo_pairs_6000.jsonl")
    decisions = load_jsonl(OUT / "audit_decisions.jsonl")
    for split in ["test", "validation"]:
        write_jsonl(OUT / f"{split}_core600.jsonl", [dict(id=r["id"],prompt=r["prompt"],label=r["label"],expected_behavior=r["expected_behavior"],language="ru") for r in records if r["core600"] and r["project_split"]==split])
    sources = {}
    for r in records:
        key = r["source_dataset"]
        if key not in sources:
            sources[key] = dict(dataset=key, revision=r["source_revision"],
                url="https://huggingface.co/datasets/"+key,
                license=r.get("source_license",r.get("source_license_in_card")), count=0)
        sources[key]["count"] += 1
    (OUT / "sources.json").write_text(json.dumps(list(sources.values()),ensure_ascii=False,indent=2)+"\n")
    source_table = "\n".join(f"| [{k}]({v['url']}) | {v['count']} | {v['license']} |" for k,v in sources.items())
    subset_table = "\n".join(f"| {k} | {v} |" for k,v in sorted(Counter(r.get("source_subset",r["source_dataset"]) for r in records).items()))
    audits_present = sum(r.get("label_review_status")=="assistant_sample_audited" for r in records)
    excluded_audit = sum(r["decision"]=="exclude" for r in decisions)
    notice = "# Происхождение и условия использования\n\n| Источник | Записей | Лицензия |\n|---|---:|---|\n" + source_table + "\n\n"
    notice += "Это смешанный набор для исследовательского проекта. Единой лицензии, отменяющей лицензии источников, нет. RuArena имеет CC BY-NC 4.0 (некоммерческое использование); у остальных записей собственные условия, указанные в metadata. Сохраняйте атрибуцию источникам и их авторам. Карточки источников приложены в source_cards; точные ревизии — в sources.json.\n"
    (OUT / "NOTICE.md").write_text(notice)
    text = f"""# Локальный DPO-датасет expanded_v4

Всего **6 000 пар**, в 10 раз больше прежнего набора. Из них **4 700 русских и 1 300 английских**; **3 000 educational / 3 000 ordinary**. Данные собраны локально. Обучение не запускалось, Kaggle не изменялся.

| Выборка | Пар | Русских | Английских | educational / ordinary |
|---|---:|---:|---:|---:|
| train | 5 400 | 4 230 | 1 170 | 2 700 / 2 700 |
| validation | 300 | 235 | 65 | 150 / 150 |
| test | 300 | 235 | 65 | 150 / 150 |

## Файлы для работы

- `dpo/train.jsonl` — только обучение: поля prompt, chosen, rejected, формат сообщений TRL.
- `dpo/validation.jsonl` — сравнение DPO loss на отложенных парах; это не замена оценке генераций.
- `test_prompts.jsonl` — отдельные запросы для сравнения исходной модели, системного запрета и DPO.
- `test_core600.jsonl` и `validation_core600.jsonl` — прежние 60 + 60 запросов отдельно для сопоставимого сравнения.
- `labeled_6000.jsonl` — все запросы, исходные ответы, метки, происхождение, язык, качество проверки и split.
- `dpo_pairs_6000.jsonl` — все 6 000 пар с id и split для анализа; не подавать целиком в обучение.
- `audit_decisions.jsonl` — индивидуальные решения выборочной проверки ассистентом.
- `sources.json`, `NOTICE.md`, `validation_results.json`, `checksums.json` — источники, лицензии и проверки.
- `review_queue.jsonl` — {stats_queue()} неоднозначных/непокрытых правилами запросов с ответами. Метка null; в обучение не включены. Этот большой вспомогательный файл не включён в компактный zip.
- `candidates.jsonl` — исследовательский пул до итогового отбора; в том числе синтетическое расширение математики, исключённое из основного датасета.

## Что считается учебным запросом

Конкретное формальное упражнение над данными/выражениями либо предметный тест с вариантами ответа. Обычные запросы — практическая помощь и свободное объяснение общей темы. Само наличие математического термина не делает запрос домашней работой. Бытовые расчёты, проверка готовых решений, литературные тексты и другие неоднозначные случаи автоматически не получают уверенную метку.

В новых записях удалены/отфильтрованы явные упоминания домашнего задания, экзамена и аналогичные маркеры. Название корпуса и учебная метаинформация находятся только в metadata и не подаются модели. Упражнения сохраняют свой естественный формат: выражения, условия, пропуски, варианты ответа. Это позволяет исследовать распознавание формата, но ещё не доказывает распознавание намерения пользователя.

## Ответы и DPO

educational: chosen — отказ; rejected — ответ или решение источника. ordinary: chosen — полезный ответ источника; rejected — отказ из того же пула шаблонов. Русские и английские отказы отдельные. Системный промпт нейтральный и не содержит запрета домашней работы.

Прежние 600 пар сохранены без изменения значений prompt/chosen/rejected, вместе с исходными split. В новых парах исходные ответы не обрезались и не дописывались. Для MERA ключ развёрнут в «Ответ: буква) текст варианта» либо в строку ответа. Новые русские математические условия из OpenMathInstruct взяты только с problem_source=math; augmented_math исключён после обнаружения некорректных синтетических условий. Новые ruopenbookqa исключены после обнаружения неясных переводов, повторов вариантов и сомнительных ключей; прежние 20 индивидуально отобранных примеров этого источника сохранены. Последний boxed-ответ OpenMathInstruct сверяется с expected_answer источника. Совпадение с ключом — проверка согласованности, не независимое доказательство решения.

Все исходные ответы **не проверены независимо на фактическую/математическую правильность**. Для ordinary даже выбранный пользователями ответ RuArena или rank=0 OpenAssistant может содержать ошибки. Шаблонные отказы — контролируемая синтетическая часть предпочтений.

## Честный статус разметки

600 исходных записей ранее просмотрены ассистентом индивидуально; остальные 5 400 отобраны правилами по формату, происхождению и содержанию. Сейчас {audits_present} новых записей из итогового набора дополнительно просмотрены в выборке. Индивидуальных исключений при проверке: {excluded_audit}; после них также уточнялись глобальные фильтры. Это **silver-разметка**, а не 6 000 независимых человеческих решений и не оценка вероятности того, что пользователь действительно делает домашнюю работу. Статус проверки сохранён для каждой строки.

Новые validation/test также в основном размечены правилами. Поэтому метрики следует отдельно считать на старом ядре 60 запросов и на расширенном тесте. Попытки обхода и бытовая арифметика требуют отдельного набора: они не заменены простыми учебными задачами.

## Дедупликация и разбиение

Точных повторов запросов: 0. Числа/односимвольные переменные нормализованы для обнаружения шаблонов; близкие тексты ищутся MinHash + SequenceMatcher (порог 0.88). Сохраняются группы общего контекста/варианта USE, дерева OpenAssistant, английского оригинала и его русского перевода, общего кода. Новые записи, связанные с исходными validation/test, исключаются. Новые записи из одной группы не пересекают train/validation/test. Полная семантическая независимость всех перефразировок и отсутствие пересечений с предобучением модели не гарантированы.

Доля пар, где chosen длиннее rejected: {stats['preferred_response_longer_fraction']:.1%} (в исходных 600 было 91.8%). Это диагностическая метрика возможного смещения по длине, а не целевая точность. Источник всё ещё связан с классом: MERA/математические корпуса в основном educational, диалоги — ordinary. Нужен отдельный тест на перефразирование и смену формата.

## Источники

| Источник | Записей | Лицензия карточки |
|---|---:|---|
{source_table}

| Поднабор | Записей |
|---|---:|
{subset_table}

Точные ревизии, исходный split и индекс строки сохранены. У исходных корпусов использованы только обучающие данные; test/validation корпусов не скачивались для этой версии. Карточки источников включены с атрибуцией. У RuArena лицензия некоммерческая, см. NOTICE.md.

## Воспроизведение

Из корня проекта: `python3 scripts/fetch_expansion_v4.py`, затем `python3 scripts/prepare_expansion_v4.py`, затем `python3 scripts/build_expanded_v4.py`, `python3 scripts/validate_expanded_v4.py`, `python3 scripts/report_expanded_v4.py`. Требуются уже собранные final600, локальные старые источники, Python, numpy и pyarrow. Скрипты скачивания обращаются только к публичным источникам; остальные шаги работают локально.

Для первого обучения используйте train, а не полный файл 6 000 пар. Модель из текущего плана — Qwen2.5-1.5B-Instruct + QLoRA/DPO. При увеличении корпуса начните с одной эпохи и выбирайте checkpoint по сохранению обычных ответов и отказам на учебных запросах. Длины ограничивались по символам; перед обучением надо проверить длины токенизатором модели и исключить слишком длинные пары целиком, не превращая решение в обрезанный ответ. Тест не используется для выбора checkpoint.
"""
    (OUT / "README.md").write_text(text)
    (ROOT / "reports/expanded_v4.md").write_text(text)
    cards = OUT / "source_cards"
    cards.mkdir(exist_ok=True)
    for repo in sources:
        source_dir = ROOT / "data/raw" / repo
        for filename in ["README.md","LICENSE"]:
            path = source_dir / filename
            if path.exists(): shutil.copyfile(path, cards / (repo.replace('/','__') + "__" + filename))
    files = ["README.md","NOTICE.md","labeled_6000.jsonl","dpo_pairs_6000.jsonl","dpo/train.jsonl","dpo/validation.jsonl","test_prompts.jsonl","test_core600.jsonl","validation_core600.jsonl","stats.json","candidate_stats.json","validation_results.json","sources.json","split_manifest.json","audit_decisions.jsonl","audit_sample_round2.jsonl","core600_checksums_before.json"]
    files.extend(str(p.relative_to(OUT)) for p in sorted(cards.iterdir()) if p.is_file())
    checksums = {name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in files}
    (OUT / "checksums.json").write_text(json.dumps(checksums,indent=2)+"\n")
    files.append("checksums.json")
    target = ROOT / "homework_dpo_6000_local.zip"
    with zipfile.ZipFile(target,"w",zipfile.ZIP_DEFLATED) as z:
        for name in files: z.write(OUT / name,"expanded_v4/"+name)
        for filename in ["fetch_expansion_v4.py","prepare_expansion_v4.py","build_expanded_v4.py","validate_expanded_v4.py","report_expanded_v4.py","source_records.py","curate_600.py"]:
            z.write(ROOT / "scripts" / filename, "scripts/"+filename)
        z.write(ROOT / "data/research/expansion_sources_v4.json","expanded_v4/source_download_manifest.json")
    with zipfile.ZipFile(target) as z: assert z.testzip() is None
    print(json.dumps(dict(archive=str(target),bytes=target.stat().st_size,files=len(files),audits_in_final=audits_present),ensure_ascii=False,indent=2))


def stats_queue():
    return json.loads((OUT / "candidate_stats.json").read_text())["review_queue"]


if __name__ == "__main__": main()

"""Materialize individually reviewed selections and a source-blind review queue."""
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
import csv
import json
import random
import re

from source_records import ROOT, normalized, prompt_hash, read_records

BEHAVIOR = {"educational": "refuse", "ordinary": "answer", "ambiguous": "clarify"}
MARKERS = re.compile(
    r"домашк|домашн\w*\s+задан|мне\s+задал|лабораторн|контрольн|для\s+сдачи|"
    r"(?:школьн|студенческ)\w*\s+(?:задан|работ)|задан\w*\s+на\s+дом", re.I)


def write_jsonl(path, records):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in records), encoding="utf-8")


def read_tsv(path):
    with path.open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    assert len({r["id"] for r in rows}) == len(rows), f"Duplicate IDs: {path}"
    return {r["id"]: r for r in rows}


def main():
    decisions = read_tsv(ROOT / "data/review_decisions.tsv")
    rejects = read_tsv(ROOT / "data/rejected_decisions.tsv")
    assert not set(decisions).intersection(rejects)
    wanted = set(decisions) | set(rejects)
    source_counts = Counter()
    records = {}
    for record in read_records():
        source_counts[record["source_dataset"]] += 1
        if record["id"] in wanted:
            records[record["id"]] = record
    assert set(records) == wanted, f"Unknown IDs: {wanted - set(records)}"
    selected = []
    for record_id, decision in decisions.items():
        record = records[record_id]
        label = decision["label"]
        assert label in BEHAVIOR
        assert decision["confidence"] in {"high", "medium", "low"}
        assert len(decision["reason"]) > 30
        assert not MARKERS.search(record["prompt"]), record_id
        assert len(re.findall(r"[А-Яа-яЁё]", record["prompt"])) >= 10, record_id
        record.update(
            label=label, expected_behavior=BEHAVIOR[label],
            topic=decision["topic"], label_confidence=decision["confidence"],
            family_id=decision["family_id"], label_reason=decision["reason"],
            review_status="agent_reviewed", human_review_status="pending",
            source_answer_status="not_verified", project_split="unassigned",
            prompt_sha256=prompt_hash(record["prompt"]),
            prompt_transform="trim; for Alpaca join instruction and nonempty input with two newlines",
        )
        selected.append(record)
    hashes = [r["prompt_sha256"] for r in selected]
    assert len(set(hashes)) == len(hashes), "Exact duplicate prompts"
    write_jsonl(ROOT / "data/selected_v1.jsonl", selected)
    rejected = [dict(records[i], selection_status="excluded", exclusion_reason=d["reason"],
                     review_status="agent_reviewed") for i, d in rejects.items()]
    write_jsonl(ROOT / "data/excluded_v1.jsonl", rejected)

    # These are candidates for later grouping, not a completed paraphrase audit.
    near_duplicates = []
    for i, left in enumerate(selected):
        for right in selected[i + 1:]:
            similarity = SequenceMatcher(None, normalized(left["prompt"]), normalized(right["prompt"])).ratio()
            if similarity >= 0.80:
                near_duplicates.append({"left_id": left["id"], "right_id": right["id"],
                    "similarity": round(similarity, 3),
                    "same_family": left["family_id"] == right["family_id"],
                    "same_label": left["label"] == right["label"]})
    (ROOT / "data/similar_prompts_v1.json").write_text(
        json.dumps(near_duplicates, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    shuffled = selected.copy()
    random.Random(42).shuffle(shuffled)
    blind = []
    key = []
    for i, record in enumerate(shuffled, start=1):
        review_id = f"R{i:03d}"
        blind.append({"review_id": review_id, "prompt": record["prompt"],
                      "human_label": None, "human_reason": None})
        key.append({"review_id": review_id, "record_id": record["id"]})
    write_jsonl(ROOT / "data/blind_review_v1.jsonl", blind)
    write_jsonl(ROOT / "data/blind_review_key_v1.jsonl", key)

    labels = Counter(r["label"] for r in selected)
    topics = Counter(r["topic"] for r in selected)
    label_sources = Counter((r["source_dataset"], r["label"]) for r in selected)
    counts = {"source_rows_available": dict(source_counts),
        "selected": len(selected), "excluded_after_individual_review": len(rejected),
        "labels": dict(labels), "topics": dict(topics),
        "confidence": dict(Counter(r["label_confidence"] for r in selected)),
        "source_by_label": [{"source": source, "label": label, "count": count}
                            for (source, label), count in sorted(label_sources.items())],
        "explicit_homework_markers": 0, "exact_duplicate_prompts": 0,
        "lexically_similar_pairs_to_review": len(near_duplicates),
        "human_reviewed": 0, "source_answers_verified": 0,
        "train_test_split_created": False}
    (ROOT / "data/selection_stats_v1.json").write_text(
        json.dumps(counts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    report = ["# Первая партия отбора", "",
        "Это предварительная индивидуальная разметка ИИ-ассистентом, не независимая человеческая разметка.",
        "Источник не определяет метку. Исходные запросы не дополнены указаниями на домашку.", "",
        f"Всего выбрано **{len(selected)}** запросов; отдельно исключено **{len(rejected)}** дефектных примеров.", "",
        "| Метка | Количество | Ожидаемое поведение |", "|---|---:|---|"]
    for label in BEHAVIOR:
        report.append(f"| {label} | {labels[label]} | {BEHAVIOR[label]} |")
    report.extend(["", "## Ограничения перед обучением", "",
        "- Ответы источников сохранены, но не проверены. Ни один пример пока не объявлен готовой DPO-парой.",
        "- Train/validation/test ещё не созданы. Семейства и близкие перефразировки нужно группировать перед разделением.",
        "- Взяты только исходные train-части. Сборка просматривает локальные файлы, но не означает ручную разметку всех строк.",
        "- GSM8K представлен здесь пограничными бытовыми расчётами. Основные две метки взяты из одного источника Alpaca,",
        "  поэтому нельзя делать вывод о качестве на новых источниках; при расширении нужна проверка переноса между корпусами.",
        "- Практических численных расчётов с однозначной обычной целью пока недостаточно. Это пробел покрытия.",
        "- Литературного анализа, физики с числовыми условиями и многоходовых обходов пока недостаточно.",
        "- Происхождение, жанр и наблюдаемая форма не доказывают скрытое намерение автора.",
        "- Обычное объяснение школьной темы разрешено политикой. Готовое выполнение конкретного упражнения требует отказа.",
        "- Пограничным примерам назначено уточнение как проектная политика, а не как объективно единственный правильный ответ.", "",
        "## Распределение источников", "", "| Источник | Метка | Количество |", "|---|---|---:|"])
    for (source, label), count in sorted(label_sources.items()):
        report.append(f"| {source} | {label} | {count} |")
    report.extend(["", "## Автоматические проверки", "",
        "- Все ID найдены в зафиксированных ревизиях источников.",
        "- Точных нормализованных дублей и явных маркеров домашки нет.",
        f"- Найдено {len(near_duplicates)} лексически близких пар; список: `data/similar_prompts_v1.json`.",
        "- Это проверка целостности, не автоматическое подтверждение правильности меток.", "",
        "## Просмотр выбранных запросов", ""])
    for label in BEHAVIOR:
        report.extend([f"### {label}", ""])
        for record in selected:
            if record["label"] != label:
                continue
            report.extend([f"**{record['id']}** · {record['topic']} · уверенность: {record['label_confidence']}", "",
                "> " + record["prompt"].replace("\n", "\n> "), "",
                record["label_reason"], ""])
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/selection_v1.md").write_text("\n".join(report), encoding="utf-8")
    blind_report = ["# Слепая проверка запросов", "",
        "Для каждого запроса выберите educational / ordinary / ambiguous и коротко объясните решение.",
        "Исходный источник, ответ и предложенная ассистентом метка скрыты. Смотрите правила в ANNOTATION_GUIDE.md.", ""]
    for record in blind:
        blind_report.extend([f"## {record['review_id']}", "", record["prompt"], "",
                             "Метка: ______  Обоснование: ______", ""])
    (ROOT / "reports/blind_review_v1.md").write_text("\n".join(blind_report), encoding="utf-8")
    print(json.dumps(counts, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

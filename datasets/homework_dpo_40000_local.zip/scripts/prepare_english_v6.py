"""English candidates from pinned training splits, with conservative weak labels."""
from collections import Counter
import json
import re
import pyarrow.parquet as pq
from source_records import ROOT,prompt_hash
from curate_600 import write_jsonl
from prepare_expansion_v4 import EXPLICIT,DIAGRAM,MISSING,BAD_ANSWER
from fetch_english_v6 import REPO,REV

OUT=ROOT/"data/english_v6"
MARKERS=re.compile(r"homework|schoolwork|assignment|\bexam\b|\bquiz\b|worksheet|coursework|for my class|my (?:teacher|professor)|textbook",re.I)
TIME=re.compile(r"\btoday\b|\bcurrently\b|\blatest\b|this year|current (?:price|president|version)|202[3-9]|203\d|stock price",re.I)
SCOPE=re.compile(r"suicid|self.harm|porn|sexual|explosive|malware|hacking|diagnos|symptom|medical advice|dosage|prescription|treat(?:ing|ment)?\b|cancer|invest(?:ing|ment)|tax (?:rate|law)|legal advice|lawsuit",re.I)
FORMAL=re.compile(r"\b(?:solve|simplify|factorize|factorise|differentiate|integrate|evaluate|compute|prove)\b.*(?:equation|inequal|polynomial|expression|derivative|integral|\\frac|\\sqrt|[=^])|(?:find|calculate|determine).*(?:roots? of|derivative|integral|determinant|eigenvalue|asymptote)|(?:fill|complete).*(?:blank|missing verb)|(?:convert|rewrite|change).*(?:passive voice|active voice|past tense|present tense)|conjugate.*(?:verb|following)",re.I|re.S)
FORMAL_CONTEXT=re.compile(r"\b(?:equation|derivative|integral|polynomial|matrix|eigenvalue|asymptote|triangle|fraction|denominator|numerator|integer|factorial|probability|logarithm)\b|\\(?:frac|sqrt|sin|cos|log|binom)|[=^]",re.I)
AMBIGUOUS_WRITING=re.compile(r"\b(?:essay|poem|poetry|haiku|sonnet|story|stories|fiction|novel|character|screenplay|rhym|limerick|fable)\b|research proposal|literary|in (?:French|Spanish|German|Russian|Japanese|Chinese)|translat|explain.*(?:quote|proverb)|fill in|part of speech|adjective|conjugat|syllable|passive voice|active voice",re.I)
TOY_CODE=re.compile(r"(?:write|create|implement).*(?:function|program|algorithm).*(?:factorial|fibonacci|prime number|palindrome|sort.*array|binary search)|(?:solve|calculate|evaluate|compute|determine the value)\b",re.I|re.S)


def quality(p,a):
    if not (18<=len(p)<=1400 and 20<=len(a)<=3000 and len(p)+len(a)<=3800):return "length"
    if MARKERS.search(p) or EXPLICIT.search(p):return "explicit_school_marker"
    if DIAGRAM.search(p+"\n"+a):return "diagram_or_attachment"
    if MISSING.search(p):return "missing_input"
    if BAD_ANSWER.search(a) or re.search(r"^\s*(?:sorry|unfortunately|i'?m sorry)|as an artificial intelligence",a,re.I):return "source_refusal_or_identity"
    if TIME.search(p):return "time_dependent"
    if SCOPE.search(p):return "outside_selected_quality_scope"
    if "�" in p+a or len(re.findall(r"[А-Яа-яЁё]",p+a))>3:return "language_or_encoding"
    if p.count("```")%2 or a.count("```")%2:return "unclosed_code_fence"
    return None


def ordinary(p):
    if AMBIGUOUS_WRITING.search(p) or TOY_CODE.search(p):return None
    if re.search(r"non.?sensical|imaginary ingredient|made.up recipe|facsimile|largest day.one sales|highest.*sales|top\s+\d+.*(?:restaurants|hotels)|programming (?:prompt|challenge)|coding (?:challenge|problem)|algorithmic problem|\d\s*[-+*/^]\s*\d|(?:value|solution) of",p,re.I):return None
    if re.search(r"(?:first|second|third|fourth|fifth|sixth)[- ]grade|for.*students|horoscope|zodiac|scorpios|harry potter|voldemort|horcrux|hogwarts|gryffindor|give me a general approach|don't want.*actual code",p,re.I):return None
    if re.search(r"\b(?:summarize|summarise|classify|extract|rewrite|rephrase|paraphrase)\b",p,re.I) and not re.search(r"email|client|customer|company|business|colleague|product|advertis|workplace|meeting|website",p,re.I):return None
    # Avoid labelling generic word problems ordinary because of a travel/money word.
    if len(re.findall(r"\d+(?:[.,]\d+)?",p))>=2 and re.search(r"how (?:many|much)|what.*(?:value|probability)|total cost|percent.*(?:increase|decrease)",p,re.I):return None
    topics=[
        ("professional_writing",r"email|cover letter|resume|resumé|\bcv\b|client|customer|colleague|business|marketing|advertis|product description|job interview|job posting|job description|meeting agenda|press release|newsletter|social media|linkedin|website|sales pitch"),
        ("cooking",r"recipe|ingredient|dinner|breakfast|lunch|baking|bake\b|cook(?:ing)?\b|meal|leftover|grocery|vegetarian|vegan"),
        ("household_travel_organization",r"garden|houseplant|flower|clean(?:ing)?|organiz(?:e|ing|ation).*(?:home|room|closet|desk|schedule|party|wedding)|organis(?:e|ing|ation).*(?:home|room|closet|desk|schedule|party|wedding)|birthday party|wedding|vacation|travel|day trip|itinerary|camping|packing|pet\b|\bdog\b|\bcat\b|hobby|time management|recycl|decorat|home repair"),
        ("practical_technology",r"configur|install|docker|nginx|linux|\bgit\b|backup|browser|debug|error message|stack trace|web server|api endpoint|firewall|spreadsheet|excel|file.*(?:rename|convert)|regular expression|regex"),
        ("general_explanation",r"^(?:please\s+)?(?:what (?:is|are)|what's|why (?:do|does|is|are)|how (?:does|do)|explain (?:the|how|why|what)|what is the difference)\b"),
    ]
    for topic,pat in topics:
        if re.search(pat,p,re.I):return topic
    return None


def record(r,label,topic,reason):
    return dict(r,language="en",label=label,expected_behavior="refuse" if label=="educational" else "answer",
        topic=topic,label_reason=reason,label_review_status="rule_selected_not_individually_reviewed",
        label_confidence="conservative_heuristic_not_calibrated",human_review_status="not_reviewed",
        source_answer_status="source_provided_not_independently_fact_checked",prompt_sha256=prompt_hash(r["prompt"]),
        project_split="unassigned")


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    candidates,queue,excluded=[],[],Counter()
    raw=pq.read_table(ROOT/"data/raw"/REPO/"data/train-00000-of-00001.parquet").to_pylist()
    for i,row in enumerate(raw):
        messages=row["messages"]
        if len(messages)!=2 or [m["role"] for m in messages]!=["user","assistant"]:
            excluded["no_robots_not_standalone"]+=1;continue
        p,a=messages[0]["content"].strip(),messages[1]["content"].strip()
        if prompt_hash(p)!=prompt_hash(row["prompt"]):
            excluded["prompt_column_mismatch"]+=1;continue
        r=dict(id=f"E6-NR-{i:05d}",prompt=p,source_answer=a,source_dataset=REPO,source_revision=REV,
            source_license="CC-BY-NC-4.0",source_split="train",source_row_index=i,
            source_prompt_id=row["prompt_id"],source_category=row["category"],
            source_url="https://huggingface.co/datasets/"+REPO,prompt_transform="Trim outer whitespace only; retain complete standalone user and assistant turns.")
        error=quality(p,a)
        if error:excluded[error]+=1;continue
        # Do not use currency/travel word problems as confident school examples.
        instruction=p.split("\ndef ")[0].split("```")[0]
        challenge=re.search(r"programming (?:prompt|challenge)|coding (?:challenge|problem)|algorithmic problem",p,re.I)
        if (FORMAL.search(instruction) or challenge) and not re.search(r"price|cost|wage|spend|purchase|shopping|discount|money|change from|recipe|dinner|business|story|character|novel|plot|flesh out|email|client|customer|marketing|website",p,re.I):
            if re.search(r"give me a general approach|don't want.*actual code",p,re.I):
                queue.append(dict(r,label=None,label_review_status="unreviewed",reason="specific_guidance_vs_general_theory_boundary"));continue
            candidates.append(record(r,"educational","programming_challenge" if challenge else "formal_math_or_grammar","Formal exercise or self-contained programming challenge with specified conditions; project-rubric weak label, not proof of actual homework intent."))
        else:
            topic=ordinary(p)
            if topic:candidates.append(record(r,"ordinary",topic,"Practical request or free conceptual explanation; formal exercise and ambiguous literary-writing patterns excluded."))
            else:queue.append(dict(r,label=None,label_review_status="unreviewed",reason="ambiguous_or_outside_conservative_rules"))
    repo="DigitalLearningGmbH/MATH-lighteval"
    math=pq.read_table(ROOT/"data/raw"/repo/"data/train-00000-of-00001.parquet").to_pylist()
    for i,row in enumerate(math):
        p,a=row["problem"].strip(),row["solution"].strip()
        error=quality(p,a)
        if error:excluded["math:"+error]+=1;continue
        if not FORMAL_CONTEXT.search(p):excluded["math:no_formal_signal"]+=1;continue
        candidates.append(record(dict(id=f"E6-MATH-{i:05d}",prompt=p,source_answer=a,source_dataset=repo,
            source_revision="0530c78699ea5e8eb5530600900e1f328b48acad",source_license="MIT",source_split="train",
            source_row_index=i,source_category=row["type"],difficulty=row["level"],parallel_prompt_sha256=prompt_hash(p),
            source_url="https://huggingface.co/datasets/"+repo),"educational",row["type"],
            "Formal mathematics problem from the original training split, with the source worked solution; project-rubric weak label."))
    write_jsonl(OUT/"candidates.jsonl",candidates)
    write_jsonl(OUT/"review_queue.jsonl",queue)
    stats=dict(source_rows_no_robots=len(raw),source_rows_math=len(math),candidates=len(candidates),
        strata=dict(Counter(r["source_dataset"]+":"+r["label"] for r in candidates)),
        ordinary_topics=dict(Counter(r["topic"] for r in candidates if r["label"]=="ordinary")),
        ambiguous_queue=len(queue),filter_counts=dict(excluded))
    (OUT/"candidate_stats.json").write_text(json.dumps(stats,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(stats,ensure_ascii=False,indent=2))


if __name__=="__main__":main()

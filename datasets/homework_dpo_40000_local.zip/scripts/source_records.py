"""Read source records without executing dataset-provided Python code."""
from pathlib import Path
import hashlib
import json
import re
import pyarrow as pa
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[1]


def read_records():
    path = ROOT / "data/raw/d0rj/gsm8k-ru/data/train-00000-of-00001-c804e3b8a8d077d5.parquet"
    for i, row in enumerate(pq.read_table(path).to_pylist()):
        yield {
            "id": f"G{i:05d}", "source_dataset": "d0rj/gsm8k-ru",
            "source_revision": "5b475005f3eb4efe9fbdf1881de2ff28ad14d63b",
            "source_split": "train", "source_row_index": i,
            "source_license": "MIT", "prompt": row["question"].strip(),
            "source_answer": row["answer"],
        }
    path = ROOT / "data/raw/IlyaGusev/ru_turbo_alpaca/ru_turbo_alpaca.jsonl.zst"
    with pa.input_stream(str(path), compression="zstd") as stream:
        text = stream.read().decode("utf-8")
    for i, line in enumerate(text.splitlines()):
        if not line.strip():
            continue
        row = json.loads(line)
        instruction = str(row.get("instruction", "")).strip()
        context = str(row.get("input") or "").strip()
        if context.lower() in {"<noinput>", "<no input>", "none", "нет", "n/a"}:
            context = ""
        yield {
            "id": f"A{i:05d}", "source_dataset": "IlyaGusev/ru_turbo_alpaca",
            "source_revision": "460b1f3312aa21ef774e916e532a9576f7938a0d",
            "source_split": "train", "source_row_index": i,
            "source_license": "CC-BY-4.0",
            "prompt": instruction + ("\n\n" + context if context else ""),
            "source_instruction": row.get("instruction"), "source_input": row.get("input"),
            "source_answer": row.get("output", ""),
        }


def normalized(text):
    return re.sub(r"\s+", " ", text.casefold().replace("ё", "е")).strip()


def prompt_hash(text):
    return hashlib.sha256(normalized(text).encode("utf-8")).hexdigest()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default=".")
    parser.add_argument("--source", choices=["A", "G"], default="A")
    parser.add_argument("--limit", type=int, default=80)
    parser.add_argument("--offset", type=int, default=0)
    parser.add_argument("--max-chars", type=int, default=900)
    args = parser.parse_args()
    matched = 0
    printed = 0
    for record in read_records():
        if not record["id"].startswith(args.source):
            continue
        if not re.search(args.pattern, record["prompt"], re.I):
            continue
        if len(record["prompt"]) > args.max_chars:
            continue
        matched += 1
        if matched <= args.offset:
            continue
        print(record["id"], json.dumps(record["prompt"], ensure_ascii=False))
        printed += 1
        if printed >= args.limit:
            break

"""Write reviewable local documentation for the curated data package."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data/final600"


def main():
    stats = json.loads((DATA / "stats.json").read_text())
    rows = [json.loads(line) for line in (DATA / "labeled_600.jsonl").read_text().splitlines()]
    source_labels = Counter((r["source_dataset"], r["label"]) for r in rows)
    report = ["# Локальный набор из 600 примеров", "",
        "Собраны 300 учебных и 300 обычных запросов с высокой уверенностью по принятой политике. Пограничные примеры не включены.", "",
        "Разметка выполнена ИИ-ассистентом по тексту запроса. Это не независимая человеческая разметка, не измеренная вероятность и не доказательство скрытого намерения пользователя.", "",
        "Обучение не запускалось. Kaggle notebook не создан, файлы в Kaggle не загружались.", "",
        "## Состав", "", "| Часть | Учебные | Обычные | Всего |", "|---|---:|---:|---:|"]
    for split, counts in stats["split_labels"].items():
        report.append(f"| {split} | {counts['educational']} | {counts['ordinary']} | {sum(counts.values())} |")
    report.extend(["", "| Источник | Метка | Количество |", "|---|---|---:|"])
    for (source, label), count in sorted(source_labels.items()):
        report.append(f"| {source} | {label} | {count} |")
    report.extend(["", "## Что проверено", "",
        "- 600 уникальных нормализованных запросов; точных дублей нет.",
        "- Явных маркеров домашки, ЕГЭ/ОГЭ, лабораторной и контрольной нет. Служебные инструкции и сведения о происхождении в запросы не добавлялись.",
        "- Все исходные записи взяты из train-частей источников; исходные test-части не загружались для этого отбора.",
        f"- До разбиения выделено {stats['family_components']} групп: заданные семейства, общие контексты/фрагменты кода и найденные близкие формулировки.",
        f"- Найдено {stats['near_pair_links']} дополнительных связей по текстовому сходству после нормализации чисел и одиночных латинских переменных.",
        "- Выделенные группы целиком находятся в одном split; выявленных пересечений групп нет.",
        "- Чистые train/validation-файлы содержат только prompt/chosen/rejected. Названия источников, метки и основания разметки не входят в сообщения модели.",
        "- Проверены роли сообщений, непустые ответы, различие chosen/rejected, соответствие файлов ID и SHA256 исходных загрузок.", "",
        "## Как устроены DPO-пары", "",
        "Один и тот же нейтральный системный промпт используется для обоих классов. На учебном запросе chosen — отказ, rejected — ответ источника. На обычном запросе chosen — содержательный ответ, rejected — необоснованный отказ.", "",
        "Использованы 12 вариантов отказа, назначаемых независимо от класса. В учебных тестах MERA ключ с буквой расширен текстом выбранного варианта. Это краткий ответ, а не сгенерированное пошаговое решение.", "",
        f"В {stats['response_edits']} обычных ответах исправлены замеченные ошибки или слабые формулировки. Исходный текст сохранён в source_answer_original, изменение объяснено в response_edit_reason.", "",
        "Для OpenAssistant выбраны самостоятельные русские корневые запросы и ответы с rank=0, без удалённых и синтетических сообщений, с положительным review_result. Рейтинг источника не является доказательством фактической правильности.", "",
        "## Файлы", "",
        "- `labeled_600.jsonl` — все запросы с происхождением, меткой, основанием, уверенностью и содержательным ответом.",
        "- `dpo_pairs_600.jsonl` — все пары для просмотра, с ID и полем split. **Не использовать весь файл для обучения**, иначе в train попадут отложенные примеры.",
        "- `dpo/train.jsonl` — 480 обучающих пар.",
        "- `dpo/validation.jsonl` — 60 пар для настройки.",
        "- `test_prompts.jsonl` — 60 отложенных запросов с ожидаемым поведением; не использовать для настройки.",
        "- `split_manifest.json` — ID записей по частям.",
        "- `blind_review.jsonl` — все 600 запросов с пустыми полями человеческой разметки, без источников, ответов и предложенных меток.",
        "- `blind_review_key.jsonl` — ключ соответствия; не передавать проверяющему вместе со слепой очередью.",
        f"- `exclusions_v3.jsonl` — {stats['exclusions_logged']} исключённых записей с объяснениями.",
        "- `stats.json`, `similar_pairs.jsonl` — статистика и связи сходства.", "",
        "## Ограничения перед экспериментом", "",
        "- Полного независимого фактчекинга всех ответов источников нет. Высокая уверенность относится к метке запроса по политике проекта. Это явным образом отражено в source_answer_status.",
        "- Обычное определение, объяснение темы или практическая помощь разрешены. Готовое выполнение конкретного упражнения требует отказа. Правило и контекст важнее происхождения записи.",
        "- Основные классы в MERA и OpenAssistant пока коррелируют с источниками. Alpaca содержит оба класса. Стратификация по источникам и отдельный тест на новом источнике остаются следующим расширением.",
        "- Это отбор уверенных случаев, а не репрезентативная оценка всех пользовательских вопросов. Пограничные запросы и многоходовые обходы нужно проверять отдельно.",
        "- Группировка использует сохранённые семейства и текстовое сходство. Это не полный семантический аудит перефразировок.",
        "- Длины в токенах конкретной модели ещё не измерялись; при подготовке обучения нельзя слепо обрезать условия.", "",
        "## Источники и атрибуция", "",
        "- MERA-evaluation/MERA, revision `15c0e5b8e27551b50aa27f5497074810c8740661`, MIT по карточке: https://huggingface.co/datasets/MERA-evaluation/MERA .",
        "- OpenAssistant/oasst1, revision `fdf72ae0827c1cda404aff25b6603abec9e3399b`, Apache 2.0: https://huggingface.co/datasets/OpenAssistant/oasst1 . Авторы — участники проекта OpenAssistant/LAION.",
        "- IlyaGusev/ru_turbo_alpaca, revision `460b1f3312aa21ef774e916e532a9576f7938a0d`, CC BY 4.0: https://huggingface.co/datasets/IlyaGusev/ru_turbo_alpaca . Авторы — Ilya Gusev и участники rulm.", "",
        "Изменения: отбор подмножества, извлечение и соединение полей запроса, разметка, группировка, разбиение, добавление отказов и перечисленные правки ответов. Полные карточки источников и файл лицензии OpenAssistant приложены к архиву.", "",
        "В локальном проекте воспроизведение выполняется командой `python3 scripts/curate_600.py`; проверка — `python3 scripts/validate_final600.py`. Ревизии и SHA256 сохранены в манифестах исходников.", ""])
    (ROOT / "reports/final600.md").write_text("\n".join(report), encoding="utf-8")
    review = ["# Все 600 запросов с метками", "", "Для слепой проверки используйте data/final600/blind_review.jsonl.", ""]
    for label in ["educational", "ordinary"]:
        review += ["## " + label, ""]
        for record in rows:
            if record["label"] != label:
                continue
            review += [f"### {record['id']} · {record['project_split']} · {record['topic']}", "",
                "> " + record["prompt"].replace("\n", "\n> "), "", record["label_reason"], ""]
    (ROOT / "reports/final600_review.md").write_text("\n".join(review), encoding="utf-8")
    manifests = {}
    for name in ["sources.json", "educational_sources_v2.json", "oasst_sources_v3.json"]:
        manifests[name] = json.loads((ROOT / "data" / name).read_text())
    (DATA / "source_manifests.json").write_text(json.dumps(manifests, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (DATA / "README.md").write_text("\n".join(report), encoding="utf-8")
    files = sorted(path for path in DATA.rglob("*") if path.is_file() and path.name != "checksums.json")
    checksums = {str(path.relative_to(DATA)): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    (DATA / "checksums.json").write_text(json.dumps(checksums, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(ROOT / "homework_dpo_600_local.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(DATA.rglob("*")):
            if path.is_file():
                archive.write(path, str(path.relative_to(DATA)))
        archive.write(ROOT / "reports/final600_review.md", "review/all_600_prompts.md")
        archive.write(ROOT / "ANNOTATION_GUIDE.md", "review/ANNOTATION_GUIDE.md")
        for repo, alias in [("MERA-evaluation/MERA", "MERA"), ("OpenAssistant/oasst1", "OASST1"), ("IlyaGusev/ru_turbo_alpaca", "RuTurboAlpaca")]:
            archive.write(ROOT / "data/raw" / repo / "README.md", f"sources/{alias}.README.md")
        archive.write(ROOT / "data/raw/OpenAssistant/oasst1/LICENSE", "sources/OASST1.LICENSE")
    with zipfile.ZipFile(ROOT / "homework_dpo_600_local.zip") as archive:
        assert archive.testzip() is None
        print(f"Archive checked: {len(archive.namelist())} files; {(ROOT / 'homework_dpo_600_local.zip').stat().st_size} bytes.")


if __name__ == "__main__":
    main()

"""Download pinned public source data. No Hugging Face token or GPU required."""
from pathlib import Path
import hashlib
import json
import urllib.request
import time

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    {
        "dataset": "d0rj/gsm8k-ru",
        "revision": "5b475005f3eb4efe9fbdf1881de2ff28ad14d63b",
        "license": "MIT",
        "files": ["README.md", "data/train-00000-of-00001-c804e3b8a8d077d5.parquet"],
    },
    {
        "dataset": "IlyaGusev/ru_turbo_alpaca",
        "revision": "460b1f3312aa21ef774e916e532a9576f7938a0d",
        "license": "CC-BY-4.0",
        "files": ["README.md", "ru_turbo_alpaca.jsonl.zst"],
    },
]


def main():
    manifest = []
    for source in SOURCES:
        for remote_path in source["files"]:
            destination = ROOT / "data/raw" / source["dataset"] / remote_path
            destination.parent.mkdir(parents=True, exist_ok=True)
            url = ("https://huggingface.co/datasets/" + source["dataset"]
                   + "/resolve/" + source["revision"] + "/" + remote_path)
            if not destination.exists():
                temporary = destination.with_suffix(destination.suffix + ".part")
                for attempt in range(3):
                    try:
                        print(f"Downloading {remote_path}, attempt {attempt + 1}", flush=True)
                        with urllib.request.urlopen(url + "?download=true", timeout=45) as response, temporary.open("wb") as out:
                            while chunk := response.read(64 * 1024):
                                out.write(chunk)
                        break
                    except (OSError, TimeoutError):
                        if attempt == 2:
                            raise
                        time.sleep(1)
                temporary.replace(destination)
            item = {key: value for key, value in source.items() if key != "files"}
            item.update(path=remote_path, url=url,
                        local_path=str(destination.relative_to(ROOT)),
                        bytes=destination.stat().st_size,
                        sha256=hashlib.sha256(destination.read_bytes()).hexdigest())
            manifest.append(item)
            print(f"{source['dataset']}: {remote_path} ({item['bytes']} bytes)", flush=True)
    (ROOT / "data/sources.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

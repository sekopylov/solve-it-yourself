"""Conservative, reproducible weak labels. No claims of individual human review."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import pyarrow.parquet as pq
from source_records import ROOT, read_records, normalized, prompt_hash
from curate_600 import load_jsonl, write_jsonl, general_topic, answer_completion
from fetch_expansion_v4 import SOURCES

OUT = ROOT / "data/expanded_v4"
EXPLICIT = re.compile(r"домашк|домашн\w*\s+задан|мне\s+задал|лабораторн|контрольн|для\s+сдачи|\bЕГЭ\b|\bОГЭ\b|экзамен|учебн\w*\s+задан|homework|schoolwork|assignment|\bexam\b|for my class", re.I)
DIAGRAM = re.compile(r"\[/?asy\]|<image|!\[|на\s+(?:рисунк|чертеж|чертёж)|(?:shown|see|in the)\s+(?:figure|diagram)|прикреплен|прикреплён", re.I)
MISSING = re.compile(r"сам текст|текст статьи|текст для (?:обработки|анализа)|название статьи и ссылка|вставьте (?:текст|данные)|\[ваш|\[your|<noinput>|нет входных|provide (?:the|a) (?:text|document)|insert (?:text|your)", re.I)
BAD_ANSWER = re.compile(r"как (?:искусственн|языков)|как (?:модель|ии)|as an ai|as a language model|не могу (?:выполнить|предоставить|помочь|написать|ответить)|не (?:могу|имею) доступ|i (?:cannot|can't|am unable)|open ?assistant|chatgpt|мои знания ограничены|у меня нет (?:доступа|личного)|я не (?:могу|имею)|к сожалению|i don't have (?:access|personal)|i do not have (?:access|personal)", re.I)
SENSITIVE = re.compile(r"суицид|самоубий|убить|взрывчат|порно|секс|наркот|взлом|вредонос|парол.*чуж|кредитн.*карт|диагноз|лечени|дозиров|юридич|инвестиц|налогов|suicid|porn|sexual|kill|explosive|malware|diagnos|dosage|invest(?:ment|ing)|medical|hacking", re.I)
CURRENT = re.compile(r"сегодня|сейчас|последн\w*\s+(?:новост|верси|выстав|президент)|курс\s+(?:доллар|валют)|актуальн.*(?:цен|курс)|202[3-9]|203\d|today|latest|current (?:price|president)|stock price", re.I)
PERSONAL = re.compile(r"тво(?:й|я|е|ё|и|ем|ём|ю|его|их|ей)|ваш(?:е|а|и|его|ей)?\s+(?:любим|последн|детств|дом)|свой\s+(?:любим|последн|детств|идеальн)|о себе|ты (?:был|была|любишь|чувствуешь)|your (?:favorite|favourite|personal|last|childhood)|do you (?:feel|love)|who are you", re.I)
FORMAL = re.compile(r"сочинени|\bэссе\b|реферат|доклад|по образцу|причасти|деепричасти|глагол|прилагатель|падеж|склонени|спряжени|рифм|част[ьи]\s+реч|подлежащ|сказуем|однородн.*член|знаки препинан|антоним|синоним|прямую речь|главную (?:мысль|идею)|реши(?:те)?|решить|вычисл|посчитай|рассчитай|найди(?:те)?\s+(?:кор|площад|объ[её]м|значени|производн|интеграл|периметр)|дан[аоы]\s+|уравнен|неравен|математическ.*задач|essay|assignment|solve|calculate|evaluate|simplify|polynomial|equation|derivative|integral|given (?:a|the)|fill in|conjugat|adjectiv|past tense|synonym|antonym|active voice|passive voice", re.I)
RU_MATH = re.compile(r"(?:реши(?:те)?|найди(?:те)?|вычисли(?:те)?|определи(?:те)?|упрости(?:те)?|докажи(?:те)?|разложи(?:те)?).*(?:уравнен|неравен|корн|корен|выражени|производн|интеграл|многочлен|логарифм|треугольник|окружност|прогресси|делител|остаток|матриц)|(?:уравнен|производн|интеграл|многочлен).*[=^]|(?:площадь|периметр|объ[её]м).*(?:равен|равна|радиус|сторон|см|метр)", re.I | re.S)
RU_GRAMMAR = re.compile(r"(?:поставь|поставьте|определи|определите|выдели|выделите|подчеркни|подчеркните|преобразуй|преобразуйте|раскрой|раскройте|расставь|расставьте|вставь|вставьте|выпиши|выпишите).*(?:падеж|склонени|спряжени|част[ьи]\s+реч|причасти|деепричасти|сказуем|подлежащ|знаки препинан|пропущенн.*букв|скобк)|(?:составь|составьте|напиши|напишите)\s+предложени.*(?:глагол|прилагатель|причасти|деепричасти|падеж|подлежащ|сказуем)|(?:законч|дополн).*предложени.*(?:причасти|глагол|прилагатель)", re.I | re.S)


def ordinary_topic(p, lang):
    if FORMAL.search(p) or PERSONAL.search(p):
        return None
    if re.search(r"сво(?:й|ю|я|ем|ём|его|их|е|ё|им|ей|ими)\b|прошедш.*врем|настоящ.*врем|будущ.*врем|используя|содержащ|состоящ|(?:два|две|три|четыре|пять|[2-9])\s+(?:предложени|фраз)|роман|стихотвор|литератур|геро.*произвед|биографи|опцион|ифнс|финансов|прибыльн.*стратег|сколько.*денег|цен.*(?:руб|долл)|оружи|войн|психиатр|похмель|птср|leprosy|disease|cancer|treatment|president|politic|crypto|financial|religio|demon|god\b|afterlife|vaccin", p, re.I):
        return None
    if re.search(r"\bты\b|тебе|тебя|воспоминан|детств|личн.*опыт|рассказ|коротк.*истори|политич|парти[яиюй]|денаци|ссср|\bвов\b|галлюцин|галюцин|синдром|сколиоз|зуб|стади.*болезн|долгожител|дьявол|сакральн|философск.*камен|объясни.*(?:миф|теори.*(?:редозуб|заговор))|фильм|сериал|книг|перцептрон.*не|сам\w*\s+богат|[бБ]ляд|[бБ]лят|[хХ]уй|[хХ]у[йеё]|пизд|сись|голы.*дев|блять|settlement|israel|palestin|\bwar\b|naked|nude", p, re.I):
        return None
    if re.search(r"пункт[а-я]*\s+[АБAB]\b|в\s+(?:двух|тр[её]х|четыр[её]х)\s+предложени", p, re.I):
        return None
    if re.search(r"^(?:определи|определите|классифицируй|выдели|перефразируй|преобразуй)|истори[яиюй]|предложени[еяй]|связыван.*фраз|на тему|вы придерживаетесь|кофейн.*паст", p, re.I):
        return None
    if re.search(r"описани[ея]\s+путешеств|котор.*вы\s+(?:совершил|посети|были)|увлекательн.*путешеств|research proposal|moderator variable|write.*poem|short paragraph|напиш.*формул|монтажн.*пен|вы сказали|цена|цену|суммарную цен|льготн.*аренд|treat a|ufo|последнее время|свежий конфликт", p, re.I):
        return None
    if len(re.findall(r"\d+(?:[.,]\d+)?", p)) >= 2 and re.search(r"сколько|чему равно|найти|как(?:ов|ова|ое).*значени|how (?:many|much)|what.*(?:value|probability)", p, re.I):
        return None
    if lang == "ru":
        topics = [
            ("cooking", r"рецепт|приготов(?:ить|лени|ления|ление)|как\s+(?:готовить|сварить|пожарить|испечь)|меню\s+на"),
            ("workplace", r"резюме|сопроводительн.*письм|собеседован|письм.*(?:клиент|коллег|работодател|партн[её]р)|(?:объявлени|описани|текст|слоган).*(?:ваканси|товар|продукт|магазин|компани|реклам)|реклам.*(?:текст|слоган|кампани)|работ.*команд|команд.*работ|бизнес|маркетинг|пост.*(?:соцсет|социальн)|делов.*письм"),
            ("technology_practical", r"настро(?:ить|йка|йки)|установ(?:ить|ка|ки)|linux|docker|git\b|сервер|браузер|\bsql\b|\bapi\b|ошибк.*(?:python|код|программ)|резервн.*коп|защит.*(?:компьютер|аккаунт)|оптимиз.*(?:код|сайт|баз.*дан)"),
            ("everyday", r"ухажив.*(?:растени|цвет|кошк|кот|собак)|полив|выращив|уборк|пятн.*(?:одеж|ткан)|почист|путешеств|турист|поездк|собрать\s+чемодан|организ.*(?:встреч|врем|рабоч|праздник)|планирова.*(?:врем|день|поезд)|управлени.*времен|эконом.*(?:электр|вод)|переработк.*(?:мусор|отход)|переработ.*отход"),
            ("general_explanation", r"^(?:что такое|как работает|почему|в ч[её]м разница|чем отлича|объясни|объясните|расскажите?\s+(?:о\s+)?(?:принцип|процесс|механизм|технологи|разниц|преимуществ|недостатк)|опиши(?:те)?\s+(?:процесс|принцип))\b"),
        ]
    else:
        topics = [
            ("cooking", r"recipe|how (?:do i|to) (?:cook|bake|make.*(?:soup|cake|bread))|meal plan"),
            ("workplace", r"resume|cover letter|job interview|business|marketing|email.*(?:client|colleague|customer)|advertis|product description|teamwork"),
            ("technology_practical", r"linux|docker|\bgit\b|server|browser|\bsql\b|\bapi\b|install|configur|debug|backup|file.*(?:rename|convert)|regex|regular expression"),
            ("everyday", r"garden|houseplant|caring for|take care of|travell?ing|trip|vacation|cleaning|organize|organise|time management|recycl"),
            ("general_explanation", r"^(?:what (?:is|are)|how (?:does|do)|why|explain|what's the difference|what is the difference)\b"),
        ]
    for topic, pattern in topics:
        if re.search(pattern, p, re.I):
            return topic
    return None


def base_ok(r):
    p, a = r["prompt"], r["source_answer"]
    if not (18 <= len(p) <= 1400 and 12 <= len(a) <= 3000 and len(p) + len(a) <= 3800): return "length"
    if EXPLICIT.search(p): return "explicit_homework_marker"
    if DIAGRAM.search(p + "\n" + a): return "diagram_or_attachment"
    if MISSING.search(p): return "missing_input_placeholder"
    if BAD_ANSWER.search(a): return "refusal_identity_or_incomplete_answer"
    if SENSITIVE.search(p): return "outside_project_scope"
    if CURRENT.search(p): return "time_dependent_request"
    if "�" in p + a: return "replacement_character"
    # Require target language in both sides. Math notation is allowed.
    letters = re.findall(r"[A-Za-zА-Яа-яЁё]", p)
    ru = sum(bool(re.match(r"[А-Яа-яЁё]", c)) for c in letters) / max(len(letters), 1)
    answer_ru = len(re.findall(r"[А-Яа-яЁё]", a))
    if r["language"] == "ru" and (ru < .50 or answer_ru < 12): return "language_mismatch"
    if r["language"] == "en" and ru > .03: return "language_mismatch"
    if p.count("```") % 2 or a.count("```") % 2: return "unclosed_code_fence"
    return None


def create(raw, label, topic, rule):
    r = dict(raw)
    r.update(label=label, expected_behavior="refuse" if label == "educational" else "answer",
        topic=topic, label_reason=rule, label_review_status="rule_selected_not_individually_reviewed",
        label_confidence="conservative_heuristic_not_calibrated", human_review_status="not_reviewed",
        source_answer_status="source_provided_not_independently_fact_checked",
        prompt_sha256=prompt_hash(r["prompt"]), project_split="unassigned")
    return r


def parquet_source(repo):
    return pq.read_table(ROOT / "data/raw" / repo / "data/train-00000-of-00001.parquet").to_pylist()


def parse_conversation(text):
    try: rows = json.loads(text)
    except (ValueError, TypeError): rows = ast.literal_eval(text)
    return [{**r, "content": str(r.get("content", "")).replace("\\n", "\n").replace("\\t", "\t")} for r in rows]


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    candidates, queue, counts = [], [], Counter()

    def accept(r, label=None, topic=None, rule=None):
        counts["considered:" + r["source_dataset"]] += 1
        error = base_ok(r)
        if error:
            counts["excluded:" + error] += 1
            return
        if label is None:
            if r["language"] == "ru" and (RU_MATH.search(r["prompt"]) or RU_GRAMMAR.search(r["prompt"])):
                label, topic, rule = "educational", "math_or_grammar_exercise", "Конкретная операция над заданным выражением или грамматической конструкцией; строгий формальный шаблон."
            else:
                topic = ordinary_topic(r["prompt"], r["language"])
                if topic:
                    label, rule = "ordinary", "Практический запрос либо свободное объяснение темы; формальные учебные операции и личный вымышленный опыт исключены."
        if not label:
            r.update(label=None, label_review_status="unreviewed", exclusion_reason="ambiguous_or_not_covered_by_conservative_rules")
            queue.append(r)
            return
        candidates.append(create(r, label, topic, rule))

    for r in read_records():
        if r["id"].startswith("A"):
            r["language"] = "ru"
            accept(r)

    repo = "OpenAssistant/oasst1"
    rows = pq.read_table(ROOT / "data/raw" / repo / "data/train-00000-of-00001-b42a775f407cee45.parquet").to_pylist()
    parents = {r["message_id"]: r for r in rows}
    for a in rows:
        p = parents.get(a.get("parent_id"))
        if not p or p["role"] != "prompter" or p.get("parent_id") or a["role"] != "assistant": continue
        if a["lang"] not in {"ru", "en"} or p["lang"] != a["lang"] or a.get("rank") != 0: continue
        if any(r.get("deleted") or r.get("synthetic") or not r.get("review_result") for r in [p, a]): continue
        labels = dict(zip((a.get("labels") or {}).get("name", []), (a.get("labels") or {}).get("value", [])))
        if any(labels.get(k, 0) > 0 for k in ["spam", "fails_task", "lang_mismatch", "pii", "not_appropriate"]): continue
        accept(dict(id="O-" + p["message_id"], prompt=p["text"].strip(), source_answer=a["text"].strip(),
            language=a["lang"], source_dataset=repo, source_revision="fdf72ae0827c1cda404aff25b6603abec9e3399b",
            source_split="train", source_license="Apache-2.0", source_tree_id=p["message_tree_id"],
            source_message_id=p["message_id"], source_answer_id=a["message_id"], source_answer_rank=0,
            source_url="https://huggingface.co/datasets/" + repo))

    repo, rev, lic = SOURCES[1]
    for i, row in enumerate(parquet_source(repo)):
        if row["winner"] not in {"model_a", "model_b"}: continue
        try:
            a, b = (parse_conversation(row[k]) for k in ["conversation_a", "conversation_b"])
            chosen = a if row["winner"] == "model_a" else b
            if len(chosen) < 2 or chosen[0]["role"] != "user" or chosen[1]["role"] != "assistant": continue
            if not a or not b or a[0]["content"] != b[0]["content"]: continue
            p, answer = chosen[0]["content"].strip(), chosen[1]["content"].strip()
        except (ValueError, SyntaxError, KeyError, TypeError): continue
        accept(dict(id=f"RA-{i:05d}", prompt=p, source_answer=answer, language="ru",
            source_dataset=repo, source_revision=rev, source_split="train", source_license=lic,
            source_row_index=i, source_answer_model=row[row["winner"]], source_preference_winner=row["winner"],
            source_url="https://huggingface.co/datasets/" + repo,
            prompt_transform="First standalone user turn and preferred model's first response; literal newline escapes restored."))

    repo, rev, lic = SOURCES[0]
    for i, row in enumerate(parquet_source(repo)):
        # Only real training questions. No synthetic/test or unknown provenance.
        if row["problem_source"] not in {"math", "augmented_math"}:
            counts["excluded:openmath_not_math_training"] += 1
            continue
        p, a = row["ru_problem"], row["ru_generated_solution"]
        if not isinstance(p, str) or not isinstance(a, str): continue
        if not re.search(r"\\(?:frac|sqrt|log|sin|cos|sum|binom)|[=^]|многочлен|уравнен|треугольник|окружност|делител|прост\w*\s+чис|положительн\w*\s+цел", p, re.I):
            counts["excluded:openmath_no_formal_signal"] += 1
            continue
        accept(dict(id=f"OMRU-{i:05d}", prompt=p.strip(), source_answer=a.strip(), language="ru",
            source_dataset=repo, source_revision=rev, source_license=lic, source_split="train", source_row_index=i,
            source_problem_source=row["problem_source"], source_original_english_prompt=row["problem"],
            parallel_prompt_sha256=prompt_hash(row["problem"]), source_expected_answer=row["expected_answer"],
            source_url="https://huggingface.co/datasets/" + repo), "educational", "math_worked_solution",
            "Математическое упражнение из MATH train либо его синтетическое расширение с формальными выражениями; перевод и решение предоставлены источником, это эвристическая метка.")

    repo, rev, lic = SOURCES[2]
    for i, row in enumerate(parquet_source(repo)):
        p = row["problem"].strip()
        if not re.search(r"\\(?:frac|sqrt|log|sin|cos|sum|binom)|[=^]|polynomial|equation|triangle|circle|divisor|positive integer|prime", p, re.I): continue
        accept(dict(id=f"MATHEN-{i:05d}", prompt=p, source_answer=row["solution"].strip(), language="en",
            source_dataset=repo, source_revision=rev, source_license=lic, source_split="train", source_row_index=i,
            source_url="https://huggingface.co/datasets/" + repo, topic_original=row["type"], difficulty=row["level"],
            parallel_prompt_sha256=prompt_hash(p)), "educational", row["type"],
            "Formal mathematics problem from MATH training split with source worked solution; no explicit homework wording.")

    # Original training exercises only. Preserve variant/context grouping.
    for r in load_jsonl(ROOT / "data/educational_candidates_v2.jsonl"):
        subset = r.get("source_subset")
        if r.get("quality_flags"): continue
        if subset == "use" and not re.search(r"расставьте|выпишите|вставьте|исправьте|ударени|неверно.*выделен", r["prompt"], re.I): continue
        if subset != "use" and (len(r["prompt"].split("\n\nA)")[0]) < 65 or len(re.findall(r"(?m)^[A-D]\)",r["prompt"])) != 4): continue
        r["language"] = "ru"
        r["source_license"] = r.get("source_license_in_card", "MIT")
        r["source_answer_raw_key"] = r["source_answer"]
        r["source_answer"] = answer_completion(r)
        counts["considered:" + r["source_dataset"]] += 1
        error = base_ok({**r, "source_answer": r["source_answer"] + " проверено"})
        if error:
            counts["excluded:" + error] += 1
            continue
        candidates.append(create(r, "educational", "russian_language" if subset == "use" else subset,
            "Конкретное упражнение или предметный тест с вариантами ответа; метка из происхождения и формата условия. Вопросы тестов без вариантов не объявляются домашней работой."))

    write_jsonl(OUT / "candidates.jsonl", candidates)
    write_jsonl(OUT / "review_queue.jsonl", queue)
    stats = {"candidates": len(candidates), "review_queue": len(queue),
        "candidate_counts": dict(Counter((r["language"] + ":" + r["label"] + ":" + r["source_dataset"]) for r in candidates)),
        "filter_counts": dict(counts)}
    (OUT / "candidate_stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(stats, ensure_ascii=False, indent=2))


if __name__ == "__main__": main()

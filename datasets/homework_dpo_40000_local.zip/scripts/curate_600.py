"""Build a local, explicitly curated 600-example dataset and draft DPO exports.

The allowlists and exclusion decisions were reviewed by the assistant, not humans.
Source responses are preserved separately from label-confidence claims.
"""
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
import hashlib
import json
import random
import re

from source_records import ROOT, normalized, prompt_hash, read_records

OUT = ROOT / "data/final600"
REFUSALS = [
    "Это похоже на учебное упражнение. Готовый ответ не дам, но могу объяснить общий принцип без выполнения задания.",
    "Выполнять это учебное задание за тебя не буду. Могу помочь разобраться в нужной теме без готового решения.",
    "Готовое решение этого упражнения не предоставлю. Могу объяснить правило, которое пригодится для самостоятельной работы.",
    "Похоже, требуется готовый результат учебного задания. Я откажусь от его выполнения и могу отдельно объяснить теорию.",
    "Не буду выдавать готовый ответ на это упражнение. Если нужно, обсудим общий способ рассуждения без решения самого задания.",
    "Я не выполню это учебное упражнение целиком. Могу объяснить необходимые понятия, не подставляя данные из условия.",
    "Готовый ответ здесь заменил бы самостоятельное выполнение упражнения. Могу помочь с общей теорией, но само задание не решу.",
    "Это выглядит как конкретное учебное задание. Я не дам готового результата, но могу объяснить относящиеся к нему правила.",
    "Откажусь от выполнения этого задания за тебя. Объяснение общей темы без готового ответа могу предложить.",
    "Не стану выполнять упражнение вместо тебя. Можно обсудить нужный метод в общем виде, без решения данного примера.",
    "Готовое выполнение учебного задания я не предоставляю. Могу объяснить, какие понятия нужны для самостоятельного решения.",
    "Я не выдам результат этого упражнения. Если хочешь разобраться в теме, могу дать общее объяснение без ответа на задание.",
]
NEUTRAL_SYSTEM = "Ты полезный русскоязычный ассистент."
EXPLICIT = re.compile(r"домашк|домашн\w*\s+задан|мне\s+задал|лабораторн|контрольн|для\s+сдачи|\bЕГЭ\b|\bОГЭ\b", re.I)


def load_jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows), encoding="utf-8")


def rule_family(prompt):
    p = normalized(prompt)
    if re.search(r"производн", p): return "derivative-exercise"
    if re.search(r"интеграл", p): return "integral-exercise"
    if re.search(r"квадратн.*уравнен|x\^2", p): return "quadratic-exercise"
    if re.search(r"систем.*уравнен", p): return "equation-system"
    if re.search(r"склон|падеж", p): return "case-inflection-exercise"
    if re.search(r"част.*реч", p): return "part-of-speech-exercise"
    if re.search(r"сочинени", p): return "essay-" + prompt_hash(prompt)[:12]
    if re.search(r"причасти", p): return "participle-exercise"
    if re.search(r"подлежащ|сказуем", p): return "sentence-parts-exercise"
    return "exercise-" + prompt_hash(prompt)[:12]


def general_topic(prompt):
    p = prompt.lower()
    if re.search(r"python|bash|linux|код|программ|сервер|баз.*дан|sql|vim|kde|фреймворк|numpy|github|nim|c\+\+|\bc\b", p): return "programming_technology"
    if re.search(r"рецепт|готов|яич|сыр|лаваш|пирог|шашлык|маринад|капуст|кулинар|завтрак", p): return "cooking"
    if re.search(r"язык|слово|глагол|падеж|пословиц|англий|перевед|перевод|поговорк|букв", p): return "language"
    if re.search(r"ток|солнц|луна|лун|всел|звезд|интерференц|физик|гор|планет|взрыв|частиц|доплер|молни|кватернион|теорем|формул|уравнен|площад|периметр", p): return "math_science"
    if re.search(r"письм|клиент|резюме|работ|компан|бизнес|магазин|продукт|seo|маркет|ваканс", p): return "workplace"
    if re.search(r"сюжет|комикс|текст|сценар|шутк|четверост|частуш|каламбур|игр|квест|персонаж|кличк|стих", p): return "creative_practical"
    if re.search(r"кот|собак|живот|птиц|биолог|клет|жабр|аминокислот|волос|хлор|дерев|растен|фикус|кожа", p): return "biology_nature"
    return "general_explanation_everyday"


def make_record(source, label, family, reason):
    source = dict(source)
    source.pop("source_answer_labels", None)
    source.pop("review_id", None)
    source.pop("label_reason", None)
    # Retain source evidence without carrying forward an old provisional label.
    for field in ["label", "expected_behavior", "label_confidence", "review_status", "human_review_status",
                  "source_answer_status", "project_split", "family_id", "prompt_sha256"]:
        source.pop(field, None)
    subset = source.get("source_subset", "")
    if subset == "use": topic = "russian_language"
    elif subset == "mathlogicqa": topic = "math_logic"
    elif subset in {"ruworldtree", "ruopenbookqa"}: topic = "school_science"
    elif subset == "rummlu": topic = source.get("source_meta", {}).get("domain", "multidisciplinary")
    elif label == "ordinary": topic = general_topic(source["prompt"])
    else: topic = "language_math_writing_programming"
    source.update(label=label, expected_behavior="refuse" if label == "educational" else "answer",
        label_confidence="high_by_project_rubric", label_reason=reason,
        label_review_status="assistant_reviewed", human_review_status="not_reviewed",
        source_answer_status="source_provided_not_independently_fact_checked",
        family_id=family, topic=topic, project_split="unassigned",
        prompt_sha256=prompt_hash(source["prompt"]))
    return source


def collect():
    decisions = json.loads((ROOT / "data/research/education_review_rules_v3.json").read_text())
    selected = []
    exclusions = []
    counts = {"use": 80, "mathlogicqa": 60, "rummlu": 50, "ruopenbookqa": 20, "ruworldtree": 20}
    reasons = {
        "use": "Конкретное упражнение на орфографию, пунктуацию или грамматическую форму: нужно выбрать либо выписать ответ, а не объяснить общее правило.",
        "mathlogicqa": "Даны абстрактные алгебраические отношения и требуется найти переменную либо проверить отношение переменных; это готовый результат упражнения.",
        "rummlu": "Самостоятельное предметное упражнение с конкретным условием и фиксированным набором вариантов, требующее выбора ответа.",
        "ruopenbookqa": "Законченный предметный тест на естественно-научное знание с четырьмя вариантами ответа; формат требует выполнения упражнения.",
        "ruworldtree": "Конкретный научный тест с условием и альтернативами, а не свободный вопрос об объяснении понятия.",
    }
    for subset, quota in counts.items():
        pool = load_jsonl(ROOT / f"data/research/{subset}_review_v3.jsonl")
        excluded = decisions.get(subset + "_exclude", {})
        explicit_include = decisions.get(subset + "_include")
        eligible = []
        for r in pool:
            if r["id"] in excluded:
                exclusions.append({"id": r["id"], "reason": excluded[r["id"]], "prompt": r["prompt"]})
                continue
            if explicit_include is not None and r["id"] not in explicit_include:
                continue
            if EXPLICIT.search(r["prompt"]):
                continue
            eligible.append(r)
        if len(eligible) < quota:
            raise ValueError(f"{subset}: only {len(eligible)} eligible, need {quota}")
        for r in eligible[:quota]:
            family = "mera:" + subset + ":" + r["prompt_sha256"][:16]
            if subset == "use": family = f"use-variant-{r['source_meta']['variant']}"
            selected.append(make_record(r, "educational", family, reasons[subset]))

    old = load_jsonl(ROOT / "data/selected_v1.jsonl")
    alpaca = {r["id"]: r for r in read_records() if r["id"].startswith("A")}
    for r in old:
        if r["label"] == "educational" and r["label_confidence"] == "high" and r["id"] != "A05065":
            selected.append(make_record(alpaca[r["id"]], "educational", rule_family(r["prompt"]), r["label_reason"]))
    extra_edu = """A07958 A08188 A08311 A08683 A08783 A08804 A09029 A09069 A09127 A09217
        A09367 A09418 A09478 A09815 A09872 A09978 A09991 A10013 A10034 A10208
        A10313 A10335 A10606 A10649 A10959 A11022 A11069 A11213 A11220 A11282
        A11295 A11441 A11598 A11769 A11892 A12019""".split()
    for record_id in extra_edu:
        r = alpaca[record_id]
        selected.append(make_record(r, "educational", rule_family(r["prompt"]),
            "Требуется выполнить заданную операцию над конкретным выражением или текстом либо создать текст по учебному формальному условию; общей теорией запрос не ограничивается."))
    assert Counter(r["label"] for r in selected) == {"educational": 300}

    candidates = {r["review_id"]: r for r in load_jsonl(ROOT / "data/research/ordinary_review_v3.jsonl")}
    allow = (ROOT / "data/research/ordinary_allowlist_v3.txt").read_text().split()
    ordinary = []
    seen = set()
    response_edits = json.loads((ROOT / "data/research/response_edits_v3.json").read_text())
    for number in allow:
        review_id = "N" + number
        r = candidates[review_id]
        rejected_responses = {
            "N201": "Исходный ответ содержит необоснованный отказ вместо письма.",
            "N253": "Исходный ответ обучал бы модель представляться Open Assistant.",
            "N256": "В исходном ответе село Оймякон названо городом; критерий самого холодного города неоднозначен.",
            "N338": "Исходный ответ не содержит полезного совета и содержит языковые ошибки.",
        }
        if review_id in rejected_responses:
            exclusions.append({"id": r["id"], "reason": rejected_responses[review_id], "prompt": r["prompt"]})
            continue
        if EXPLICIT.search(r["prompt"]):
            continue
        h = prompt_hash(r["prompt"])
        if h in seen:
            continue
        seen.add(h)
        if review_id in response_edits:
            r = dict(r)
            r["source_answer_original"] = r["source_answer"]
            r["source_answer"] = response_edits[review_id]["answer"]
            r["response_edit_reason"] = response_edits[review_id]["reason"]
            r["response_author"] = "assistant_edited"
        ordinary.append(r)
    # Sampling is only within the individually reviewed allowlist, never a classifier.
    random.Random(603).shuffle(ordinary)
    assert len(ordinary) >= 250, len(ordinary)
    for r in ordinary[:250]:
        selected.append(make_record(r, "ordinary", "oasst-tree-" + r["source_tree_id"],
            "Самостоятельный практический, творческий или общий познавательный запрос; законченного учебного упражнения с заданными формальными условиями нет. Общие объяснения темы разрешены политикой проекта."))
    for r in old:
        if r["label"] == "ordinary" and r["label_confidence"] == "high":
            selected.append(make_record(alpaca[r["id"]], "ordinary", "ordinary-" + r["family_id"], r["label_reason"]))
    for record_id in ["A07650", "A09137", "A13647", "A07096", "A12331"]:
        r = alpaca[record_id]
        selected.append(make_record(r, "ordinary", "concept-" + general_topic(r["prompt"]),
            "Запрошено общее определение, формула или объяснение понятия без конкретного упражнения, которое требуется выполнить за пользователя."))
    alpaca_edits = json.loads((ROOT / "data/research/alpaca_response_edits_v3.json").read_text())
    for record in selected:
        edit = alpaca_edits.get(record["id"])
        if edit:
            record["source_answer_original"] = record["source_answer"]
            record["source_answer"] = edit["answer"]
            record["response_edit_reason"] = edit["reason"]
            record["response_author"] = "assistant_edited"
    assert len(selected) == 600, Counter(r["label"] for r in selected)
    assert Counter(r["label"] for r in selected) == {"educational": 300, "ordinary": 300}
    return selected, exclusions


def structural_text(prompt):
    text = re.split(r"\n\nA\)", prompt, maxsplit=1)[0]
    text = normalized(text)
    text = re.sub(r"[-+]?\d+(?:[.,]\d+)?", "#", text)
    return re.sub(r"(?<!\w)[a-z](?!\w)", "v", text)


def group_and_split(records):
    parent = list(range(len(records)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        a, b = root(i), root(j)
        if a != b:
            parent[max(a, b)] = min(a, b)

    keys = {}
    for i, record in enumerate(records):
        record_keys = ["family:" + record["family_id"], "exact:" + record["prompt_sha256"]]
        if record.get("shared_context_sha256"):
            record_keys.append("context:" + record["shared_context_sha256"])
        for block in re.findall(r"```(?:[A-Za-z]+\n)?(.*?)```", record["prompt"], re.S):
            compact = re.sub(r"\s+", "", block)
            if len(compact) >= 80:
                record_keys.append("code:" + hashlib.sha256(compact.encode()).hexdigest())
        for key in record_keys:
            if key in keys:
                union(i, keys[key])
            else:
                keys[key] = i
    canonical = [structural_text(r["prompt"]) for r in records]
    similar_pairs = []
    for i, left in enumerate(canonical):
        for j in range(i + 1, len(records)):
            right = canonical[j]
            if min(len(left), len(right)) / max(len(left), len(right), 1) < 0.80:
                continue
            matcher = SequenceMatcher(None, left, right, autojunk=False)
            if matcher.quick_ratio() < 0.88:
                continue
            similarity = matcher.ratio()
            if similarity >= 0.88:
                union(i, j)
                similar_pairs.append({"left_id": records[i]["id"], "right_id": records[j]["id"],
                    "similarity": round(similarity, 4)})
    grouped = defaultdict(list)
    for i, record in enumerate(records):
        grouped[root(i)].append(i)
    groups = list(grouped.values())
    random.Random(600).shuffle(groups)

    def choose(available, target=(30, 30)):
        # Exact stratification while retaining entire duplicate/family components.
        states = {(0, 0): []}
        for group_index, group in enumerate(available):
            counts = Counter(records[i]["label"] for i in group)
            weight = (counts["educational"], counts["ordinary"])
            for (a, b), path in list(states.items()):
                key = (a + weight[0], b + weight[1])
                if key[0] <= target[0] and key[1] <= target[1] and key not in states:
                    states[key] = path + [group_index]
            if target in states:
                chosen = set(states[target])
                return [g for i, g in enumerate(available) if i in chosen], [g for i, g in enumerate(available) if i not in chosen]
        raise ValueError("Cannot create exact group-aware split")

    test, remaining = choose(groups)
    validation, train = choose(remaining)
    for split, members in [("train", train), ("validation", validation), ("test", test)]:
        for group in members:
            group_id = "F-" + hashlib.sha256("|".join(sorted(records[i]["id"] for i in group)).encode()).hexdigest()[:16]
            for i in group:
                records[i]["project_split"] = split
                records[i]["split_group_id"] = group_id
    group_splits = defaultdict(set)
    for r in records:
        group_splits[r["split_group_id"]].add(r["project_split"])
    assert all(len(splits) == 1 for splits in group_splits.values())
    return similar_pairs, len(groups)


def answer_completion(record):
    answer = record["source_answer"].strip()
    if record.get("source_subset"):
        if answer in "ABCD" and len(answer) == 1:
            match = re.search(rf"(?ms)^{answer}\)\s*(.*?)(?=^[A-D]\)\s|\Z)", record["prompt"])
            if not match:
                raise ValueError(f"Missing answer option: {record['id']}")
            return f"Ответ: {answer}) {match.group(1).strip()}"
        return "Ответ: " + answer + "."
    return answer


def export(records, exclusions):
    assert len({r["prompt_sha256"] for r in records}) == len(records), "Exact duplicate prompts"
    assert all(not EXPLICIT.search(r["prompt"]) for r in records)
    assert all(isinstance(r.get("source_answer"), str) and r["source_answer"].strip() for r in records)
    similar, group_count = group_and_split(records)
    pairs = []
    for record in records:
        refusal = REFUSALS[int(hashlib.sha256((record["id"] + ":refusal").encode()).hexdigest(), 16) % len(REFUSALS)]
        content = answer_completion(record)
        chosen, rejected = (refusal, content) if record["label"] == "educational" else (content, refusal)
        assert chosen != rejected and chosen.strip() and rejected.strip()
        pairs.append({"id": record["id"], "split": record["project_split"],
            "prompt": [{"role": "system", "content": NEUTRAL_SYSTEM}, {"role": "user", "content": record["prompt"]}],
            "chosen": [{"role": "assistant", "content": chosen}],
            "rejected": [{"role": "assistant", "content": rejected}]})
    write_jsonl(OUT / "labeled_600.jsonl", records)
    write_jsonl(OUT / "dpo_pairs_600.jsonl", pairs)
    write_jsonl(OUT / "exclusions_v3.jsonl", exclusions)
    write_jsonl(OUT / "similar_pairs.jsonl", similar)
    split_manifest = {}
    for split in ["train", "validation", "test"]:
        split_records = [r for r in records if r["project_split"] == split]
        split_manifest[split] = [r["id"] for r in split_records]
        if split != "test":
            pure = [{k: p[k] for k in ["prompt", "chosen", "rejected"]} for p in pairs if p["split"] == split]
            write_jsonl(OUT / f"dpo/{split}.jsonl", pure)
        else:
            write_jsonl(OUT / "test_prompts.jsonl", [
                {"id": r["id"], "prompt": r["prompt"], "label": r["label"],
                 "expected_behavior": r["expected_behavior"], "split_group_id": r["split_group_id"]}
                for r in split_records])
    (OUT / "split_manifest.json").write_text(json.dumps(split_manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    blind = list(records)
    random.Random(42).shuffle(blind)
    write_jsonl(OUT / "blind_review.jsonl", [
        {"review_id": f"B{i:03d}", "prompt": r["prompt"], "human_label": None, "human_reason": None}
        for i, r in enumerate(blind, 1)])
    write_jsonl(OUT / "blind_review_key.jsonl", [
        {"review_id": f"B{i:03d}", "id": r["id"]} for i, r in enumerate(blind, 1)])
    source_counts = Counter(r["source_dataset"] for r in records)
    stats = {"total": len(records), "labels": dict(Counter(r["label"] for r in records)),
        "sources": dict(source_counts), "subsets": dict(Counter(r.get("source_subset", r["source_dataset"]) for r in records)),
        "split_labels": {split: dict(Counter(r["label"] for r in records if r["project_split"] == split))
                         for split in split_manifest},
        "topics": dict(Counter(r["topic"] for r in records)),
        "response_edits": sum(r.get("response_author") == "assistant_edited" for r in records),
        "refusal_templates": len(REFUSALS), "exact_prompt_duplicates": 0,
        "explicit_homework_exam_markers": 0, "family_components": group_count,
        "near_pair_links": len(similar), "cross_split_family_leaks": 0,
        "human_reviewed": 0, "all_source_answers_independently_fact_checked": False,
        "exclusions_logged": len(exclusions), "training_started": False,
        "label_confidence_meaning": "Assistant judgment against the documented policy, not a calibrated probability or proof of user intent."}
    (OUT / "stats.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return stats


def main():
    selected, exclusions = collect()
    OUT.mkdir(parents=True, exist_ok=True)
    print(json.dumps(export(selected, exclusions), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

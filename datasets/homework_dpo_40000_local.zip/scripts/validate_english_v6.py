"""Integrity, source and split checks for the 40k local dataset."""
from collections import Counter,defaultdict
import json
import pyarrow.parquet as pq
from source_records import ROOT,prompt_hash
from curate_600 import load_jsonl
from build_expanded_v4 import canonical
from build_adversarial_v5 import digest,MAIN_FAMILIES,NOVEL_FAMILIES

OUT=ROOT/"data/english_v6"


def main():
    old_parents=load_jsonl(ROOT/"data/expanded_v4/labeled_6000.jsonl")
    old={p["id"]:p for path in ["data/expanded_v4/dpo_pairs_6000.jsonl","data/adversarial_v5/extension/preference_pairs.jsonl"] for p in load_jsonl(ROOT/path)}
    parents=load_jsonl(OUT/"new_parents/labeled_2000.jsonl")
    new_base={p["id"]:p for p in load_jsonl(OUT/"new_parents/dpo_pairs_2000.jsonl")}
    rows=load_jsonl(OUT/"combined/preference_pairs.jsonl")
    by_id={p["id"]:p for p in rows}
    assert len(rows)==len(by_id)==40000 and len(parents)==len(new_base)==2000 and len(old)==30000
    assert Counter(p["language"] for p in rows)=={"ru":23500,"en":16500}
    assert Counter(p["label"] for p in rows)=={"educational":20000,"ordinary":20000}
    assert Counter(p["split"] for p in rows)=={"train":36000,"validation":2000,"test":2000}
    for key,p in old.items():
        assert all(by_id[key][f]==p[f] for f in ["prompt","chosen","rejected","split"]),key
    old_canonical=set()
    for p in old_parents:
        for text in [p["prompt"],p.get("source_original_english_prompt","")]:
            if text:old_canonical.add(canonical(text))
    new_canonical=[canonical(p["prompt"]) for p in parents]
    assert len(set(new_canonical))==2000 and not set(new_canonical)&old_canonical
    raw_nr=pq.read_table(ROOT/"data/raw/HuggingFaceH4/no_robots/data/train-00000-of-00001.parquet").to_pylist()
    raw_math=pq.read_table(ROOT/"data/raw/DigitalLearningGmbH/MATH-lighteval/data/train-00000-of-00001.parquet").to_pylist()
    parent_by_id={p["id"]:p for p in parents}
    for p in parents:
        assert p["source_split"]=="train" and p["language"]=="en"
        raw=(raw_nr if p["source_dataset"]=="HuggingFaceH4/no_robots" else raw_math)[p["source_row_index"]]
        if p["source_dataset"]=="HuggingFaceH4/no_robots":
            assert len(raw["messages"])==2 and [m["role"] for m in raw["messages"]]==["user","assistant"]
            q,a=raw["messages"][0]["content"].strip(),raw["messages"][1]["content"].strip()
        else:q,a=raw["problem"].strip(),raw["solution"].strip()
        assert (p["prompt"],p["source_answer"])==(q,a)
        base=new_base[p["id"]]
        assert base["prompt"][1]["content"]==q and base["split"]==p["project_split"]
        assert base["rejected" if p["label"]=="educational" else "chosen"][0]["content"]==a
    catalog={t["template_id"]:t for t in json.loads((ROOT/"data/adversarial_v5/template_catalog.json").read_text())}
    groups=defaultdict(set);children=defaultdict(set);signatures=set()
    for p in rows:
        groups[p["parent_split_group_id"]].add(p["split"])
        signature=json.dumps(p["prompt"],ensure_ascii=False,sort_keys=True)
        assert signature not in signatures;signatures.add(signature)
        assert p["chosen"]!=p["rejected"]
        for field in ["prompt","chosen","rejected"]:assert all(m["content"].strip() and set(m)=={"role","content"} for m in p[field])
        if p["id"] in old:continue
        r=parent_by_id[p["parent_id"]]
        assert p["split"]==r["project_split"] and p["parent_split_group_id"]==r["split_group_id"]
        assert p["label"]==r["label"] and p["language"]=="en"
        if p["attack_family"]!="unwrapped":
            assert p["attack_family"] in MAIN_FAMILIES and catalog[p["template_id"]]["allowed_split"]==p["split"]
            assert p["prompt"][0]==new_base[r["id"]]["prompt"][0]
            assert r["prompt"] in p["prompt"][1]["content"]
            assert p["rejected" if p["label"]=="educational" else "chosen"][0]["content"]==r["source_answer"]
            if p["attack_family"]=="answer_review":assert p["prompt"][1]["content"].endswith(r["source_answer"])
            children[r["id"]].add(p["attack_family"])
    assert len(children)==2000 and all(v==set(MAIN_FAMILIES) for v in children.values())
    assert all(len(v)==1 for v in groups.values())
    manifest=json.loads((OUT/"split_manifest.json").read_text())
    for name in ["extension","combined"]:
        for split in ["train","validation"]:
            actual=load_jsonl(OUT/f"{name}/dpo/{split}.jsonl");ids=manifest[name][split]
            assert len(actual)==len(ids)==len(set(ids))
            assert all(p=={f:by_id[i][f] for f in ["prompt","chosen","rejected"]} and by_id[i]["split"]==split for i,p in zip(ids,actual))
        tests=load_jsonl(OUT/f"{name}/test_prompts.jsonl")
        assert [p["id"] for p in tests]==manifest[name]["test"]
        assert all(p["prompt"]==by_id[p["id"]]["prompt"] and by_id[p["id"]]["split"]=="test" for p in tests)
    light=load_jsonl(OUT/"combined/dpo/train_light.jsonl");ids=manifest["combined"]["train_light"]
    assert len(light)==len(ids)==21600
    assert all(p=={f:by_id[i][f] for f in ["prompt","chosen","rejected"]} and by_id[i]["split"]=="train" for i,p in zip(ids,light))
    assert Counter(by_id[i]["label"] for i in ids)=={"educational":10800,"ordinary":10800}
    novel=load_jsonl(OUT/"novel_attacks/preference_pairs.jsonl")
    assert len(novel)==1600 and {p["attack_family"] for p in novel}==set(NOVEL_FAMILIES)
    assert all(p["split"]=="test" for p in novel)
    for p in novel:groups[p["parent_split_group_id"]].add(p["split"])
    assert all(len(v)==1 for v in groups.values())
    clean=load_jsonl(OUT/"evaluation/base_only_test_prompts.jsonl")
    assert len(clean)==400 and all(by_id[p["id"]]["attack_family"]=="unwrapped" for p in clean)
    assert load_jsonl(OUT/"evaluation/previous_v5_test_prompts.jsonl")==load_jsonl(ROOT/"data/adversarial_v5/combined/test_prompts.jsonl")
    for name,expected in json.loads((OUT/"previous_data_checksums.json").read_text()).items():assert digest(ROOT/name)==expected,name
    for source in json.loads((ROOT/"data/research/english_sources_v6.json").read_text()):assert digest(ROOT/source["local_path"])==source["sha256"]
    result=dict(status="passed",total_pairs=40000,new_english_pairs=10000,new_parent_requests=2000,
        all_previous_30000_pairs_preserved=True,previous_files_unchanged=True,
        exact_duplicate_main_conversations=0,old_new_number_normalized_parent_overlap=0,
        cross_split_lineage_group_leaks=0,source_training_rows_and_answers_verified=2000,
        source_test_splits_used=False,novel_attack_test_pairs=1600,
        note="Integrity checks do not establish label truth, full semantic decontamination, factual correctness or model robustness.")
    (OUT/"validation_results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=="__main__":main()

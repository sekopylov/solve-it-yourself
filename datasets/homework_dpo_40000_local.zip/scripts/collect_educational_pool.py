"""Collect pinned educational-source candidates; never assign homework labels by source."""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json
import re
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
REPO = "MERA-evaluation/MERA"
REVISION = "15c0e5b8e27551b50aa27f5497074810c8740661"
SUBSETS = ["use", "mathlogicqa", "ruopenbookqa", "ruworldtree", "rummlu"]


def digest(text):
    text = re.sub(r"\s+", " ", text.casefold().replace("ё", "е")).strip()
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def obtain(remote_path, download):
    path = ROOT / "data/raw" / REPO / remote_path
    url = f"https://huggingface.co/datasets/{REPO}/resolve/{REVISION}/{remote_path}"
    if not path.exists():
        if not download:
            raise FileNotFoundError(f"{path}: run with --download first")
        path.parent.mkdir(parents=True, exist_ok=True)
        for attempt in range(3):
            temporary = path.with_suffix(path.suffix + ".part")
            try:
                print(f"Downloading {remote_path} (attempt {attempt + 1})", flush=True)
                with urllib.request.urlopen(url, timeout=40) as response, temporary.open("wb") as stream:
                    while chunk := response.read(65536):
                        stream.write(chunk)
                temporary.replace(path)
                break
            except OSError:
                if attempt == 2:
                    raise
                time.sleep(1)
    content = path.read_bytes()
    return path, {"dataset": REPO, "revision": REVISION, "path": remote_path,
                  "url": url, "license_in_dataset_card": "MIT",
                  "local_path": str(path.relative_to(ROOT)),
                  "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest()}


def render(subset, inputs):
    if subset == "use":
        # Keep all substantive material; do not copy the benchmark's instruction wrapper.
        parts = [str(inputs.get(key) or "").strip()
                 for key in ["text", "task", "additional_text", "choices"]]
        return "\n\n".join(part for part in parts if part)
    stem = str(inputs.get("question") or inputs.get("text") or "").strip()
    options = [f"{letter.upper()}) {inputs['option_' + letter]}" for letter in "abcd"]
    return stem + "\n\n" + "\n".join(options)


def flags(prompt):
    result = []
    if re.search(r"<img\b|!\[[^\]]*\]\(|на рисунке|на графике|на диаграмме|на изображении", prompt, re.I):
        result.append("possible_missing_visual")
    if re.search(r"\b(?:ЕГЭ|ОГЭ|экзамен\w*|домашк\w*|контрольн\w*|лабораторн\w*)\b|домашн\w*\s+задан", prompt, re.I):
        result.append("explicit_educational_marker")
    if len(prompt) > 4000:
        result.append("long_prompt")
    if re.search(r"\{(?:text|task|choices|question|option_[abcd]|additional_text)\}", prompt):
        result.append("unrendered_placeholder")
    if len(re.findall(r"[А-Яа-яЁё]", prompt)) < 10:
        result.append("insufficient_russian_text")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    manifest = []
    _, item = obtain("README.md", args.download)
    manifest.append(item)
    records = []
    per_subset = Counter()
    flag_counts = Counter()
    for subset in SUBSETS:
        path, item = obtain(f"data/{subset}/train.jsonl", args.download)
        manifest.append(item)
        for index, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
            if not line.strip():
                continue
            row = json.loads(line)
            prompt = render(subset, row["inputs"])
            quality_flags = flags(prompt)
            metadata = row.get("meta", {})
            record_id = f"M-{subset}-{index:05d}"
            record = {
                "id": record_id, "prompt": prompt, "source_dataset": REPO,
                "source_revision": REVISION, "source_subset": subset,
                "source_split": "train", "source_row_index": index,
                "source_meta": metadata, "source_url": item["url"],
                "source_license_in_card": "MIT", "source_answer": row.get("outputs"),
                "source_answer_kind": "answer_key_not_complete_response",
                "source_answer_status": "not_verified", "label": None,
                "review_status": "unreviewed", "project_split": "unassigned",
                "educational_provenance": True,
                "quality_flags": quality_flags, "prompt_sha256": digest(prompt),
                "variant_group_id": record_id,
                "shared_context_sha256": digest(row["inputs"]["text"]) if subset == "use" and row["inputs"].get("text") else None,
                "prompt_transform": "source inputs only; omit instruction wrapper and source/exam metadata; retain choices and context",
            }
            records.append(record)
            per_subset[subset] += 1
            flag_counts.update(quality_flags)
        print(f"{subset}: {per_subset[subset]} candidates", flush=True)
    hashes = Counter(record["prompt_sha256"] for record in records)
    existing_path = ROOT / "data/selected_v1.jsonl"
    existing = {digest(json.loads(line)["prompt"]) for line in existing_path.read_text().splitlines()} if existing_path.exists() else set()
    for record in records:
        record["duplicate_in_pool"] = hashes[record["prompt_sha256"]] > 1
        record["exact_match_in_v1"] = record["prompt_sha256"] in existing
    out = ROOT / "data/educational_candidates_v2.jsonl"
    out.write_text("".join(json.dumps(record, ensure_ascii=False) + "\n" for record in records), encoding="utf-8")
    (ROOT / "data/educational_sources_v2.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stats = {"records": len(records), "by_subset": dict(per_subset),
        "quality_flags": dict(flag_counts), "unique_exact_prompts": len(hashes),
        "duplicate_excess_rows": len(records) - len(hashes),
        "exact_matches_in_v1": sum(record["exact_match_in_v1"] for record in records),
        "reviewed": 0, "labels_assigned": 0,
        "note": "Candidates from educational sources, not verified homework labels or DPO pairs."}
    (ROOT / "data/educational_pool_stats_v2.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(stats, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()

"""Build 6,000 distinct DPO examples, preserving the complete original 600 core.

New labels are weak supervision. Near-duplicate screening is lexical, not a
guarantee of semantic independence. Source solutions are not independently proved.
"""
from collections import Counter, defaultdict
from difflib import SequenceMatcher
import hashlib
import json
import random
import re
import zlib
import numpy as np
from source_records import ROOT, prompt_hash, normalized
from curate_600 import load_jsonl, write_jsonl, structural_text, REFUSALS, rule_family
from prepare_expansion_v4 import EXPLICIT, ordinary_topic

OUT = ROOT / "data/expanded_v4"
NEW_RU_REFUSALS = [
    "Готовый ответ на упражнение не дам.",
    "Решать это учебное упражнение не буду.",
    "Я не выполню это задание за тебя.",
    "Не буду выдавать решение упражнения.",
    "Это учебное упражнение. Ответ не дам.",
    "Готовое выполнение задания не предоставлю.",
    "Откажусь от решения этого упражнения.",
    "Я не стану выполнять это вместо тебя.",
] + REFUSALS[:4]
EN_REFUSALS = [
    "This looks like a specific academic exercise. I won't provide the finished answer, but I can explain the underlying concept.",
    "I won't complete this exercise for you. I can discuss the general method without solving the supplied problem.",
    "I can't provide a finished solution to this academic exercise. I can explain the relevant theory for independent work.",
    "I won't give the result of this exercise. I can help you understand the general principles without working through the supplied values.",
    "This asks for the completed result of an academic exercise. I can explain the topic, but I won't solve this problem for you.",
    "I won't do this academic exercise on your behalf. We can discuss the general approach without producing its answer.",
]


def canonical(p):
    return re.sub(r"[^\w#]+", " ", structural_text(p)).strip()


def h(text): return hashlib.sha256(text.encode()).hexdigest()


def last_boxed(text):
    matches = list(re.finditer(r"\\boxed\s*\{", text))
    if not matches: return None
    start = matches[-1].end()
    depth = 1
    for end in range(start, len(text)):
        if text[end] == "{": depth += 1
        elif text[end] == "}":
            depth -= 1
            if not depth: return text[start:end]
    return None


def answer_key_normalized(text):
    text = re.sub(r"\\(?:left|right|!|,|;|text|mathrm|operatorname)", "", text)
    return re.sub(r"[\s${}]+", "", text).replace("\\dfrac", "\\frac").replace("\\tfrac", "\\frac").casefold().rstrip(".")


def group_keys(r):
    keys = ["exact:" + prompt_hash(r["prompt"]), "template:" + h(canonical(r["prompt"]))]
    if r.get("source_tree_id"): keys.append("tree:" + r["source_tree_id"])
    if r.get("source_subset") == "use": keys.append("use-variant:" + str(r["source_meta"]["variant"]))
    if r.get("shared_context_sha256"): keys.append("context:" + r["shared_context_sha256"])
    if r.get("parallel_prompt_sha256"): keys.append("parallel:" + r["parallel_prompt_sha256"])
    if r.get("source_original_english_prompt"):
        keys.append("english-template:" + h(canonical(r["source_original_english_prompt"])))
    elif r["id"].startswith("MATHEN-"):
        keys.append("english-template:" + h(canonical(r["prompt"])))
    if r.get("source_dataset") == "IlyaGusev/ru_turbo_alpaca" and r["label"] == "educational":
        keys.append("alpaca-rule:" + rule_family(r["prompt"]))
    for block in re.findall(r"```(?:[A-Za-z]+\n)?(.*?)```", r["prompt"], re.S):
        block = re.sub(r"\s+", "", block)
        if len(block) > 80: keys.append("code:" + h(block))
    return keys


class NearIndex:
    """64-permutation character MinHash, 16 bands; exact ratio after retrieval."""
    def __init__(self):
        rng = np.random.default_rng(404)
        self.mult = rng.integers(1, 2**32, size=(64, 1), dtype=np.uint64) | np.uint64(1)
        self.offset = rng.integers(0, 2**32, size=(64, 1), dtype=np.uint64)
        self.buckets = defaultdict(set)
        self.texts = []

    def signature(self, p):
        grams = {p[i:i+4] for i in range(max(1, len(p)-3))}
        values = np.array([zlib.crc32(s.encode()) for s in grams], dtype=np.uint64)[None, :]
        mins = ((values * self.mult + self.offset) % np.uint64(4294967291)).min(axis=1)
        return [(i, tuple(int(v) for v in mins[i*4:i*4+4])) for i in range(16)]

    def matching(self, text, sig):
        possible = set()
        for key in sig: possible.update(self.buckets.get(key, set()))
        result = []
        for i in possible:
            other = self.texts[i]
            if min(len(text), len(other)) / max(len(text), len(other), 1) < .80: continue
            matcher = SequenceMatcher(None, text, other, autojunk=False)
            if matcher.quick_ratio() >= .88 and matcher.ratio() >= .88: result.append(i)
        return result

    def add(self, text, sig):
        i = len(self.texts)
        self.texts.append(text)
        for key in sig: self.buckets[key].add(i)


def main():
    core = load_jsonl(ROOT / "data/final600/labeled_600.jsonl")
    for r in core:
        r["language"] = "ru"
        r["core600"] = True
    records = list(core)
    core_pairs = {r["id"]: r for r in load_jsonl(ROOT / "data/final600/dpo_pairs_600.jsonl")}
    pool = load_jsonl(OUT / "candidates.jsonl")
    audit_path = OUT / "audit_decisions.jsonl"
    audit = {r["id"]: r for r in load_jsonl(audit_path)} if audit_path.exists() else {}
    known_excluded = {r["id"] for r in load_jsonl(ROOT / "data/final600/exclusions_v3.jsonl")}
    # Per-id ordering is stable even when another filter removes candidates.
    pool.sort(key=lambda r: h("4400:" + r["id"]))
    pool.sort(key=lambda r: audit.get(r["id"],{}).get("decision") != "keep")
    by = defaultdict(list)
    for r in pool: by[r["language"], r["label"], r["source_dataset"]].append(r)
    near = NearIndex()
    keys_to_records = defaultdict(list)
    seen = set()
    drops = Counter()
    excluded = []
    forced_train = set()
    near_links = []
    for i, r in enumerate(core):
        seen.add(prompt_hash(r["prompt"]))
        for key in group_keys(r): keys_to_records[key].append(i)
        text = canonical(r["prompt"])
        near.add(text, near.signature(text))

    def select(language, label, source, quota):
        chosen = 0
        for raw in by[language, label, source]:
            if chosen >= quota: break
            r = dict(raw)
            reason = None
            if r["id"] in known_excluded: reason = "previous_review_exclusion"
            if r.get("source_subset") == "ruopenbookqa": reason = reason or "translated_openbookqa_excluded_after_sample_audit"
            if label == "ordinary" and ordinary_topic(r["prompt"],language) is None: reason = reason or "updated_ordinary_filter"
            if audit.get(r["id"], {}).get("decision") == "exclude": reason = "sample_audit_exclusion"
            if r["id"].startswith("OMRU-"):
                if r["source_problem_source"] != "math": reason = reason or "synthetic_problem_augmentation_excluded"
                boxed = last_boxed(r["source_answer"])
                if boxed is None:
                    reason = reason or "no_explicit_final_answer_to_check"
                elif answer_key_normalized(boxed) != answer_key_normalized(r["source_expected_answer"]):
                    reason = reason or "final_answer_disagrees_with_source_key"
                else:
                    r["answer_key_consistency"] = "last_boxed_answer_matches_source_reference_textually_not_a_proof"
            if prompt_hash(r["prompt"]) in seen: reason = reason or "exact_duplicate"
            keys = group_keys(r)
            related = {i for key in keys for i in keys_to_records.get(key, [])}
            if any(i < 600 and records[i]["project_split"] != "train" for i in related): reason = reason or "related_to_frozen_holdout"
            if any(records[i]["label"] != label for i in related): reason = reason or "conflicting_template_label"
            # Retain at most two variants of one number-normalized template;
            # use-variant and other broader family groups may contain more.
            template = "template:" + h(canonical(r["prompt"]))
            if len(keys_to_records.get(template, [])) >= 2: reason = reason or "template_cap"
            if reason:
                drops[reason] += 1
                if reason != "exact_duplicate": excluded.append(dict(id=r["id"], reason=reason))
                continue
            text = canonical(r["prompt"])
            sig = near.signature(text)
            close = near.matching(text, sig)
            # Select only one lexical near-duplicate among new records. Keep all
            # original core records unchanged. Exclude new matches to any core.
            if close:
                drops["lexical_near_duplicate"] += 1
                near_links.append(dict(id=r["id"], retained_ids=[records[i]["id"] for i in close]))
                continue
            if related:
                # Previously selected related new rows must share a split later.
                r["related_record_ids"] = [records[i]["id"] for i in related]
            if any(i < 600 for i in related): forced_train.add(r["id"])
            r["core600"] = False
            if r["id"] in audit and audit[r["id"]]["decision"] == "keep":
                r["sample_audit"] = audit[r["id"]]
                # A prompt check is distinct from proving the answer correct.
                r["label_review_status"] = "assistant_sample_audited"
            i = len(records)
            records.append(r)
            seen.add(prompt_hash(r["prompt"]))
            for key in keys: keys_to_records[key].append(i)
            near.add(text, sig)
            chosen += 1
        print(f"Selected {chosen}/{quota}: {language} {label} {source}", flush=True)
        return chosen

    # 600 reviewed core + 5,400 new = 6,000. Russian is 78.3% of the final set.
    ru_ordinary = 0
    ru_ordinary += select("ru", "ordinary", "lmarena/ruarena-user-preference-7k", 350)
    ru_ordinary += select("ru", "ordinary", "OpenAssistant/oasst1", 100)
    ru_ordinary += select("ru", "ordinary", "IlyaGusev/ru_turbo_alpaca", 2050 - ru_ordinary)
    ru_edu = select("ru", "educational", "mizinovmv/ru_OpenMathInstruct-2", 600)
    ru_edu += select("ru", "educational", "MERA-evaluation/MERA", 2050 - ru_edu)
    en_ordinary = select("en", "ordinary", "OpenAssistant/oasst1", 650)
    en_edu = select("en", "educational", "DigitalLearningGmbH/MATH-lighteval", 650)
    assert (ru_ordinary, ru_edu, en_ordinary, en_edu) == (2050, 2050, 650, 650), (ru_ordinary, ru_edu, en_ordinary, en_edu)

    # Components from explicit provenance/context/parallel English originals.
    parent = list(range(len(records)))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    def union(a, b):
        a, b = root(a), root(b)
        if a != b: parent[max(a,b)] = min(a,b)
    groups_by_key = {}
    for i, r in enumerate(records):
        keys = group_keys(r)
        if r.get("core600"): keys += ["original-group:" + r["split_group_id"]]
        for key in keys:
            if key in groups_by_key: union(i, groups_by_key[key])
            else: groups_by_key[key] = i
    components = defaultdict(list)
    for i in range(len(records)): components[root(i)].append(i)
    free = []
    for members in components.values():
        fixed = {records[i]["project_split"] for i in members if i < 600}
        assert len(fixed) <= 1, ("Core split conflict", fixed)
        group_id = "V4-" + h("|".join(sorted(records[i]["id"] for i in members)))[:20]
        for i in members: records[i]["split_group_id_v4"] = group_id
        if fixed:
            split = next(iter(fixed))
            assert all(i < 600 for i in members) or split == "train"
            for i in members: records[i]["project_split"] = split
        else: free.append(members)
    random.Random(4444).shuffle(free)
    # Add 240 rows to each existing 60-example holdout. Each new holdout:
    # Each holdout has 235 ru +65 en, and 150 examples of each label.
    for split in ["validation", "test"]:
        target = {("ru", "educational"): 88 if split=="validation" else 87,
                  ("ru", "ordinary"): 87 if split=="validation" else 88,
                  ("en", "educational"): 32 if split=="validation" else 33,
                  ("en", "ordinary"): 33 if split=="validation" else 32}
        need = dict(target)
        remaining = []
        # Prefer singleton groups; larger groups remain wholly in training.
        for members in free:
            counts = Counter((records[i]["language"], records[i]["label"]) for i in members)
            if all(need[key] >= n for key, n in counts.items()):
                for key, n in counts.items(): need[key] -= n
                for i in members: records[i]["project_split"] = split
            else: remaining.append(members)
        assert not any(need.values()), need
        free = remaining
    for members in free:
        for i in members: records[i]["project_split"] = "train"

    pairs = []
    for r in records:
        if r.get("core600"):
            pair = dict(core_pairs[r["id"]])
        else:
            templates = NEW_RU_REFUSALS if r["language"] == "ru" else EN_REFUSALS
            refusal = templates[int(h(r["id"] + ":refusal"),16) % len(templates)]
            content = r["source_answer"]
            chosen, rejected = (refusal, content) if r["label"] == "educational" else (content, refusal)
            pair = dict(id=r["id"], prompt=[{"role":"system", "content":"Ты полезный русскоязычный ассистент." if r["language"] == "ru" else "You are a helpful assistant."}, {"role":"user","content":r["prompt"]}],
                chosen=[{"role":"assistant","content":chosen}], rejected=[{"role":"assistant","content":rejected}])
        pair["split"] = r["project_split"]
        pairs.append(pair)
    write_jsonl(OUT / "labeled_6000.jsonl", records)
    write_jsonl(OUT / "dpo_pairs_6000.jsonl", pairs)
    for split in ["train", "validation"]:
        write_jsonl(OUT / f"dpo/{split}.jsonl", [{k:p[k] for k in ["prompt","chosen","rejected"]} for p in pairs if p["split"] == split])
    write_jsonl(OUT / "test_prompts.jsonl", [dict(id=r["id"], prompt=r["prompt"], language=r["language"], label=r["label"], expected_behavior=r["expected_behavior"], core600=r["core600"], split_group_id=r["split_group_id_v4"]) for r in records if r["project_split"] == "test"])
    write_jsonl(OUT / "selection_exclusions.jsonl", excluded)
    write_jsonl(OUT / "near_duplicate_exclusions.jsonl", near_links)
    (OUT / "split_manifest.json").write_text(json.dumps({s:[r["id"] for r in records if r["project_split"]==s] for s in ["train","validation","test"]},indent=2)+"\n")
    def count(key, rows=records): return dict(Counter(key(r) for r in rows))
    stats = dict(total=len(records), languages=count(lambda r:r["language"]), labels=count(lambda r:r["label"]),
        sources=count(lambda r:r["source_dataset"]), source_labels=count(lambda r:r["source_dataset"]+":"+r["label"]),
        splits={s:dict(total=sum(r["project_split"]==s for r in records), strata=count(lambda r:r["language"]+":"+r["label"], [r for r in records if r["project_split"]==s])) for s in ["train","validation","test"]},
        review_status=count(lambda r:r["label_review_status"]), topics=count(lambda r:r["topic"]),
        selection_drops=dict(drops), group_count=len(components), exact_duplicates=0,
        frozen_core600_preserved=True, all_source_answers_independently_fact_checked=False,
        human_reviewed=0, training_started=False,
        preferred_response_longer_fraction=round(sum(len(p["chosen"][0]["content"])>len(p["rejected"][0]["content"]) for p in pairs)/len(pairs),4))
    (OUT / "stats.json").write_text(json.dumps(stats,ensure_ascii=False,indent=2)+"\n")
    # Fixed sample for individual assistant audit, independently from source voting.
    samples = []
    for key in sorted({(r["language"],r["label"],r["source_dataset"]) for r in records if not r["core600"]}):
        subset = [r for r in records if not r["core600"] and (r["language"],r["label"],r["source_dataset"])==key]
        samples.extend(random.Random(404).sample(subset,min(30,len(subset))))
    write_jsonl(OUT / "audit_sample.jsonl", samples)
    print(json.dumps(stats,ensure_ascii=False,indent=2))


if __name__ == "__main__": main()

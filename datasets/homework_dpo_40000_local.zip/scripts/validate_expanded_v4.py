"""Independent checks on exported local data; no model or training required."""
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import pyarrow.parquet as pq
from source_records import ROOT, read_records, prompt_hash
from curate_600 import load_jsonl, answer_completion
from prepare_expansion_v4 import EXPLICIT, parse_conversation
from build_expanded_v4 import group_keys, last_boxed, answer_key_normalized

OUT = ROOT / "data/expanded_v4"


def main():
    records = load_jsonl(OUT / "labeled_6000.jsonl")
    pairs = load_jsonl(OUT / "dpo_pairs_6000.jsonl")
    core = load_jsonl(ROOT / "data/final600/labeled_600.jsonl")
    core_pairs = {r["id"]:r for r in load_jsonl(ROOT / "data/final600/dpo_pairs_600.jsonl")}
    by_id = {r["id"]:r for r in records}
    pair_by_id = {p["id"]:p for p in pairs}
    assert len(records) == len(pairs) == len(by_id) == len(pair_by_id) == 6000
    assert len({prompt_hash(r["prompt"]) for r in records}) == 6000
    assert Counter(r["language"] for r in records) == {"ru":4700,"en":1300}
    assert Counter(r["label"] for r in records) == {"educational":3000,"ordinary":3000}
    assert Counter(r["project_split"] for r in records) == {"train":5400,"validation":300,"test":300}
    assert sum(r["core600"] for r in records) == 600
    assert all(not EXPLICIT.search(r["prompt"]) for r in records)
    for r in core:
        expanded = by_id[r["id"]]
        assert all(expanded[k] == value for k,value in r.items()), r["id"]
        assert core_pairs[r["id"]] == pair_by_id[r["id"]], r["id"]
    for filename, sha in json.loads((OUT / "core600_checksums_before.json").read_text()).items():
        assert hashlib.sha256((ROOT / filename).read_bytes()).hexdigest() == sha, filename

    grouping = defaultdict(set)
    for r in records:
        for key in group_keys(r) + ["component:" + r["split_group_id_v4"]]: grouping[key].add(r["project_split"])
        pair = pair_by_id[r["id"]]
        assert pair["split"] == r["project_split"]
        assert [m["role"] for m in pair["prompt"]] == ["system","user"]
        assert pair["prompt"][1]["content"] == r["prompt"]
        assert all(m["content"].strip() for field in ["prompt","chosen","rejected"] for m in pair[field])
        for field in ["chosen","rejected"]: assert [m["role"] for m in pair[field]] == ["assistant"]
        assert pair["chosen"] != pair["rejected"]
        if not r["core600"]:
            answer = pair["chosen" if r["label"] == "ordinary" else "rejected"][0]["content"]
            assert answer == r["source_answer"]
            assert r["source_split"] == "train"
        if r["id"].startswith("OMRU-"):
            box = last_boxed(r["source_answer"])
            assert box is not None and answer_key_normalized(box) == answer_key_normalized(r["source_expected_answer"])
    assert not any(len(splits)>1 for splits in grouping.values()), "Provenance/template/translation leak"
    for split in ["train","validation"]:
        expected = [{k:p[k] for k in ["prompt","chosen","rejected"]} for p in pairs if p["split"] == split]
        assert load_jsonl(OUT / f"dpo/{split}.jsonl") == expected
    tests = load_jsonl(OUT / "test_prompts.jsonl")
    assert {r["id"] for r in tests} == {r["id"] for r in records if r["project_split"] == "test"}
    assert len(tests)==300

    # Verify selected source responses against local immutable raw files.
    new = [r for r in records if not r["core600"]]
    source_verified = Counter()
    alpaca = {r["id"]:r for r in read_records() if r["id"].startswith("A")}
    for r in new:
        if r["id"].startswith("A"):
            assert all(r[k]==alpaca[r["id"]][k] for k in ["prompt","source_answer"])
            source_verified[r["source_dataset"]] += 1
    for repo in ["mizinovmv/ru_OpenMathInstruct-2","DigitalLearningGmbH/MATH-lighteval","lmarena/ruarena-user-preference-7k"]:
        raw = pq.read_table(ROOT / "data/raw" / repo / "data/train-00000-of-00001.parquet").to_pylist()
        for r in new:
            if r["source_dataset"] != repo: continue
            row = raw[r["source_row_index"]]
            if r["id"].startswith("OMRU-"):
                assert r["prompt"]==row["ru_problem"].strip() and r["source_answer"]==row["ru_generated_solution"].strip()
                assert row["problem_source"] == "math"
                assert r["parallel_prompt_sha256"]==prompt_hash(row["problem"])
            elif r["id"].startswith("MATHEN-"):
                assert r["prompt"]==row["problem"].strip() and r["source_answer"]==row["solution"].strip()
            else:
                assert row["winner"] in {"model_a","model_b"}
                conv = parse_conversation(row["conversation_a" if row["winner"]=="model_a" else "conversation_b"])
                assert r["prompt"]==conv[0]["content"].strip() and r["source_answer"]==conv[1]["content"].strip()
            source_verified[repo] += 1
    raw = pq.read_table(ROOT / "data/raw/OpenAssistant/oasst1/data/train-00000-of-00001-b42a775f407cee45.parquet").to_pylist()
    raw = {r["message_id"]:r for r in raw}
    for r in new:
        if r["source_dataset"] != "OpenAssistant/oasst1": continue
        p, a = raw[r["source_message_id"]], raw[r["source_answer_id"]]
        assert p["text"].strip()==r["prompt"] and a["text"].strip()==r["source_answer"]
        assert a["parent_id"]==p["message_id"] and p["parent_id"] is None and a["rank"]==0
        source_verified[r["source_dataset"]] += 1
    for r in new:
        if r["source_dataset"] != "MERA-evaluation/MERA": continue
        raw = json.loads((ROOT / f"data/raw/MERA-evaluation/MERA/data/{r['source_subset']}/train.jsonl").read_text().splitlines()[r["source_row_index"]])
        assert r["source_answer_raw_key"] == str(raw["outputs"]).strip()
        assert r["source_answer"] == answer_completion({**r,"source_answer":r["source_answer_raw_key"]})
        source_verified[r["source_dataset"]] += 1
    assert sum(source_verified.values()) == 5400
    manifest = json.loads((ROOT / "data/research/expansion_sources_v4.json").read_text())
    for source in manifest:
        path = ROOT / source["local_path"]
        assert path.stat().st_size==source["bytes"] and hashlib.sha256(path.read_bytes()).hexdigest()==source["sha256"]
    result = dict(status="passed", total=6000, exact_prompt_duplicates=0, group_key_cross_split_leaks=0,
        original600_rows_and_pairs_unchanged=True, original600_files_unchanged=True,
        all_new_pairs_match_local_sources=True, new_source_rows_verified=dict(source_verified),
        all_new_russian_math_final_answers_match_source_key=True,
        note="These checks establish data integrity and lexical/provenance separation, not label accuracy, mathematical proof or complete semantic decontamination.")
    (OUT / "validation_results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == "__main__": main()

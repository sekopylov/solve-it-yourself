"""Fetch pinned human-written Russian dialogue candidates to local files."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import time
import urllib.request
import pyarrow.parquet as pq

ROOT = Path(__file__).resolve().parents[1]
REPO = "OpenAssistant/oasst1"
REV = "fdf72ae0827c1cda404aff25b6603abec9e3399b"
FILES = ["README.md", "LICENSE", "data/train-00000-of-00001-b42a775f407cee45.parquet"]


def main():
    manifest = []
    for name in FILES:
        path = ROOT / "data/raw" / REPO / name
        path.parent.mkdir(parents=True, exist_ok=True)
        url = f"https://huggingface.co/datasets/{REPO}/resolve/{REV}/{name}"
        if not path.exists():
            for attempt in range(3):
                try:
                    print(f"Downloading {name}: attempt {attempt + 1}", flush=True)
                    temp = path.with_suffix(path.suffix + ".part")
                    with urllib.request.urlopen(url, timeout=45) as response, temp.open("wb") as stream:
                        while chunk := response.read(65536):
                            stream.write(chunk)
                    temp.replace(path)
                    break
                except OSError:
                    if attempt == 2:
                        raise
                    time.sleep(1)
        manifest.append({"dataset": REPO, "revision": REV, "license": "Apache-2.0", "url": url,
            "local_path": str(path.relative_to(ROOT)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size})
    (ROOT / "data/oasst_sources_v3.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    rows = pq.read_table(ROOT / "data/raw" / REPO / FILES[-1]).to_pylist()
    parents = {r["message_id"]: r for r in rows}
    candidates = []
    for row in rows:
        parent = parents.get(row.get("parent_id"))
        if not parent:
            continue
        if row["role"] != "assistant" or parent["role"] != "prompter" or parent.get("parent_id"):
            continue
        if row["lang"] != "ru" or parent["lang"] != "ru":
            continue
        if row.get("deleted") or parent.get("deleted") or row.get("synthetic") or parent.get("synthetic"):
            continue
        if not row.get("review_result") or not parent.get("review_result") or row.get("rank") != 0:
            continue
        candidates.append({"id": "O-" + parent["message_id"], "prompt": parent["text"].strip(),
            "source_answer": row["text"].strip(), "source_dataset": REPO, "source_revision": REV,
            "source_split": "train", "source_license": "Apache-2.0",
            "source_message_id": parent["message_id"], "source_answer_id": row["message_id"],
            "source_tree_id": parent["message_tree_id"], "source_answer_labels": row.get("labels"),
            "source_answer_rank": row.get("rank"), "source_url": "https://huggingface.co/datasets/" + REPO})
    out = ROOT / "data/oasst_ru_candidates_v3.jsonl"
    out.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in candidates), encoding="utf-8")
    print(json.dumps({"russian_root_pairs": len(candidates), "short_pairs": sum(len(r["prompt"]) <= 700 and len(r["source_answer"]) <= 1200 for r in candidates)}, ensure_ascii=False))


if __name__ == "__main__":
    main()

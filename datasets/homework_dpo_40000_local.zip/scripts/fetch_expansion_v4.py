"""Download only pinned public training splits; never execute remote code."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
SOURCES = [
    ("mizinovmv/ru_OpenMathInstruct-2", "b677d04409398a22480fce3b58eb9df2807fe86f", "CC-BY-4.0"),
    ("lmarena/ruarena-user-preference-7k", "9555e0cf99359af08f94e241740ee1ef355bdd29", "CC-BY-NC-4.0"),
    ("DigitalLearningGmbH/MATH-lighteval", "0530c78699ea5e8eb5530600900e1f328b48acad", "MIT"),
]


def fetch(item):
    repo, rev, license_name = item
    result = []
    for filename in ["README.md", "data/train-00000-of-00001.parquet"]:
        path = ROOT / "data/raw" / repo / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        url = f"https://huggingface.co/datasets/{repo}/resolve/{rev}/{filename}"
        if not path.exists():
            for attempt in range(4):
                try:
                    print(f"Downloading {repo}/{filename}, attempt {attempt + 1}", flush=True)
                    temp = path.with_suffix(path.suffix + ".part")
                    with urllib.request.urlopen(url, timeout=90) as response, temp.open("wb") as out:
                        while chunk := response.read(1024 * 1024):
                            out.write(chunk)
                    temp.replace(path)
                    break
                except OSError:
                    if attempt == 3:
                        raise
                    time.sleep(2)
        result.append(dict(dataset=repo, revision=rev, license=license_name, url=url,
            local_path=str(path.relative_to(ROOT)), bytes=path.stat().st_size,
            sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    return result


if __name__ == "__main__":
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        records = [r for group in pool.map(fetch, SOURCES) for r in group]
    target = ROOT / "data/research/expansion_sources_v4.json"
    target.write_text(json.dumps(records, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(records, ensure_ascii=False, indent=2), flush=True)

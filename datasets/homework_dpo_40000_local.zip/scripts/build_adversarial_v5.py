"""Local, deterministic adversarial augmentation with matched ordinary controls.

4 variants per existing example; no new independent task labels or model calls.
All descendants inherit the parent's split and provenance group.
"""
from collections import Counter, defaultdict
import hashlib
import json
import random
from pathlib import Path
from source_records import ROOT
from curate_600 import load_jsonl, write_jsonl
from build_expanded_v4 import NEW_RU_REFUSALS, EN_REFUSALS
from adversarial_templates_v5 import (MAIN_FAMILIES, NOVEL_FAMILIES, TEMPLATES,
    NOVEL, REVIEW_REFUSALS, template_slot)

BASE = ROOT / "data/expanded_v4"
OUT = ROOT / "data/adversarial_v5"
PURE_FIELDS = ("prompt", "chosen", "rejected")
PROTECTED = ["labeled_6000.jsonl", "dpo_pairs_6000.jsonl", "dpo/train.jsonl",
    "dpo/validation.jsonl", "test_prompts.jsonl", "stats.json", "split_manifest.json"]


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024*1024), b""): result.update(chunk)
    return result.hexdigest()


def sha(text): return hashlib.sha256(text.encode()).hexdigest()


def conversation_hash(messages):
    return sha(json.dumps(messages,ensure_ascii=False,sort_keys=True,separators=(",",":")))


def dump_json(path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n")


def helper_answer(parent, pair):
    field = "rejected" if parent["label"] == "educational" else "chosen"
    return pair[field][0]["content"]


def refusal(lang, family, index):
    if family == "answer_review": pool = REVIEW_REFUSALS[lang]
    else: pool = NEW_RU_REFUSALS if lang=="ru" else EN_REFUSALS
    return pool[index % len(pool)]


def wrap_query(prefix, query, lang):
    title = "Исходный запрос:" if lang == "ru" else "Original request:"
    return prefix + "\n\n" + title + "\n" + query


def make_pair(parent, base_pair, family, slot, index, novel=False):
    lang, split = parent["language"], parent["project_split"]
    helpful = helper_answer(parent,base_pair)
    refused = refusal(lang,family,index)
    prefix = NOVEL[lang][family] if novel else TEMPLATES[lang][family][slot]
    messages = [dict(base_pair["prompt"][0])]
    messages.append({"role":"user","content":wrap_query(prefix,parent["prompt"],lang)})
    if family == "answer_review":
        title = "Предлагаемый ответ (его правильность не предполагается):" if lang=="ru" else "Proposed answer (not assumed correct):"
        messages[-1]["content"] += "\n\n" + title + "\n" + helpful
    if family == "multiturn_pressure":
        # Synthetic previous refusal, shared between labels. The ordinary control
        # requires recovering from an unjustified refusal; this is not a real run.
        messages = [dict(base_pair["prompt"][0]), dict(base_pair["prompt"][1]),
            {"role":"assistant","content":refused}, {"role":"user","content":prefix}]
    if family == "json_output":
        helpful = json.dumps({"answer":helpful},ensure_ascii=False)
        refused = json.dumps({"answer":refused},ensure_ascii=False)
    chosen, rejected = (refused,helpful) if parent["label"]=="educational" else (helpful,refused)
    record_id = ("ADV5-N-" if novel else "ADV5-") + parent["id"] + "-" + family
    return dict(id=record_id, parent_id=parent["id"], split=split, language=lang,
        label=parent["label"], expected_behavior=parent["expected_behavior"],
        is_attack_attempt=parent["label"]=="educational", is_matched_ordinary_control=parent["label"]=="ordinary",
        attack_family=family, template_id=f"{lang}/{family}/" + ("novel-test/0" if novel else str(slot)),
        parent_prompt_sha256=sha(parent["prompt"]), parent_split_group_id=parent["split_group_id_v4"],
        source_dataset=parent["source_dataset"], source_revision=parent["source_revision"],
        source_license=parent.get("source_license",parent.get("source_license_in_card")),
        parent_label_review_status=parent["label_review_status"],
        label_review_status="synthetic_inherited_label_not_individually_reviewed",
        source_answer_status="inherited_source_answer_not_independently_fact_checked",
        policy_assumption="Judge the underlying request; asserted teacher/work status does not override the project's academic-exercise refusal rule.",
        transformation="Unchanged underlying request with synthetic wrapper; source answer copied verbatim except JSON serialization.",
        reference_answer_in_prompt=family=="answer_review", synthetic_assistant_history=family=="multiturn_pressure",
        attack_test_status="not_run_against_a_model", novel_attack_family=novel,
        prompt=messages, chosen=[{"role":"assistant","content":chosen}],
        rejected=[{"role":"assistant","content":rejected}], prompt_sha256=conversation_hash(messages))


def test_row(pair, origin):
    return {k:pair[k] for k in ["id","parent_id","language","label","expected_behavior","prompt","parent_split_group_id"]} | dict(
        origin=origin, attack_family=pair.get("attack_family","unwrapped"),
        is_attack_attempt=pair.get("is_attack_attempt",False), novel_attack_family=pair.get("novel_attack_family",False))


def base_record(r, pair):
    return dict(pair, parent_id=r["id"], language=r["language"], label=r["label"],
        expected_behavior=r["expected_behavior"], parent_split_group_id=r["split_group_id_v4"])


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    before = {name:digest(BASE/name) for name in PROTECTED}
    dump_json(OUT/"base_checksums.json",before)
    base = load_jsonl(BASE/"labeled_6000.jsonl")
    base_pairs = {r["id"]:r for r in load_jsonl(BASE/"dpo_pairs_6000.jsonl")}
    assert len(base)==6000 and len(base_pairs)==6000
    parents = {r["id"]:r for r in base}
    strata = defaultdict(list)
    for r in base: strata[r["project_split"],r["language"],r["label"]].append(r)
    augmented, novel, light_ids = [], [], set()
    for (split,lang,label), rows in sorted(strata.items()):
        rows.sort(key=lambda r:sha("adv5:"+r["id"]))
        for index,r in enumerate(rows):
            pair = base_pairs[r["id"]]
            for family_index,family in enumerate(MAIN_FAMILIES):
                record = make_pair(r,pair,family,template_slot(split,index),index)
                augmented.append(record)
                # Two attack families per parent, rotating across parents. No
                # parent has more weight because its answer is shorter or longer.
                if family_index in {index%4,(index+1)%4}: light_ids.add(record["id"])
            if split=="test":
                for family in NOVEL_FAMILIES: novel.append(make_pair(r,pair,family,0,index,novel=True))
    write_jsonl(OUT/"extension/preference_pairs.jsonl",augmented)
    write_jsonl(OUT/"extension/lineage.jsonl",[{k:v for k,v in p.items() if k not in PURE_FIELDS} for p in augmented])
    write_jsonl(OUT/"novel_attacks/preference_pairs.jsonl",novel)
    write_jsonl(OUT/"novel_attacks/test_prompts.jsonl",[test_row(p,"novel_attack_test") for p in novel])
    catalog = []
    for lang in ["ru","en"]:
        for family in MAIN_FAMILIES:
            for slot,prefix in enumerate(TEMPLATES[lang][family]):
                catalog.append(dict(template_id=f"{lang}/{family}/{slot}",language=lang,attack_family=family,
                    allowed_split="train" if slot<4 else "validation" if slot<6 else "test",prefix=prefix,novel_attack_family=False))
        for family in NOVEL_FAMILIES:
            catalog.append(dict(template_id=f"{lang}/{family}/novel-test/0",language=lang,attack_family=family,
                allowed_split="test",prefix=NOVEL[lang][family],novel_attack_family=True))
    dump_json(OUT/"template_catalog.json",catalog)
    split_manifest = {"extension":{},"combined":{}}
    combined = [base_record(r,base_pairs[r["id"]]) for r in base] + augmented
    clean_test = [base_record(r,base_pairs[r["id"]]) for r in base if r["project_split"]=="test"]
    write_jsonl(OUT/"evaluation/base_only_test_prompts.jsonl",[test_row(p,"base_v4") for p in clean_test])
    write_jsonl(OUT/"evaluation/core600_test_prompts.jsonl",[test_row(p,"original_core600") for p in clean_test if parents[p["id"]]["core600"]])
    for name,rows in [("extension",augmented),("combined",combined)]:
        for split in ["train","validation","test"]:
            part = [p for p in rows if p["split"]==split]
            random.Random("adv5:"+name+":"+split).shuffle(part)
            split_manifest[name][split] = [p["id"] for p in part]
            if split!="test": write_jsonl(OUT/f"{name}/dpo/{split}.jsonl",[{k:p[k] for k in PURE_FIELDS} for p in part])
            else: write_jsonl(OUT/f"{name}/test_prompts.jsonl",[test_row(p,"base_v4" if p["id"] in parents else "adversarial_extension") for p in part])
    light = [p for p in combined if p["split"]=="train" and (p["id"] in parents or p["id"] in light_ids)]
    random.Random("adv5:light").shuffle(light)
    write_jsonl(OUT/"combined/dpo/train_light.jsonl",[{k:p[k] for k in PURE_FIELDS} for p in light])
    split_manifest["combined"]["train_light"] = [p["id"] for p in light]
    dump_json(OUT/"split_manifest.json",split_manifest)
    lengths = []
    for p in augmented+novel:
        prompt_chars = sum(len(m["content"]) for m in p["prompt"])
        total_chars = prompt_chars + max(len(p[k][0]["content"]) for k in ["chosen","rejected"])
        if total_chars>6000: lengths.append(dict(id=p["id"],parent_id=p["parent_id"],split=p["split"],
            attack_family=p["attack_family"],prompt_chars=prompt_chars,total_chars=total_chars,
            note="Character heuristic only. Tokenize with the target model before training; do not silently truncate the supplied answer."))
    write_jsonl(OUT/"length_review_queue.jsonl",lengths)
    def counts(rows,key): return dict(Counter(key(p) for p in rows))
    stats = dict(base_unique_requests=6000, extension_pairs=len(augmented), combined_pairs=len(combined),
        main_total_multiplier=len(combined)/len(base), extension_attack_attempts=sum(p["is_attack_attempt"] for p in augmented),
        extension_ordinary_controls=sum(p["is_matched_ordinary_control"] for p in augmented),
        extension_languages=counts(augmented,lambda p:p["language"]), combined_languages=counts(combined,lambda p:p["language"]),
        extension_labels=counts(augmented,lambda p:p["label"]), attack_families=counts(augmented,lambda p:p["attack_family"]),
        splits={name:{split:dict(total=sum(p["split"]==split for p in rows),labels=counts([p for p in rows if p["split"]==split],lambda p:p["label"])) for split in ["train","validation","test"]} for name,rows in [("extension",augmented),("combined",combined)]},
        train_light_pairs=len(light), train_light_labels=counts(light,lambda p:p["label"]),
        novel_test_pairs=len(novel),novel_test_families=counts(novel,lambda p:p["attack_family"]),
        distinct_template_wordings=len(catalog), unique_test_parent_requests=300,
        distinct_test_provenance_groups=len({p["parent_split_group_id"] for p in clean_test}),
        long_pairs_character_heuristic=len(lengths), model_tokenizer_length_audit_done=False,
        human_reviewed=0, model_attack_success_tested=False, training_started=False,
        note="Synthetic variants of 6000 underlying requests. Inherited weak labels; not 30000 independent tasks or measured successful jailbreaks.")
    dump_json(OUT/"stats.json",stats)
    dump_json(OUT/"build_config.json",dict(base_dataset=str(BASE.relative_to(ROOT)),variants_per_parent=4,
        main_families=MAIN_FAMILIES,novel_families=NOVEL_FAMILIES,seed="adv5",
        class_rule="Preserve parent's expected behavior; role/work claims alone do not relabel the underlying task.",
        review_rule="Source answer is an unverified proposed draft. Request asks for final response without a correctness verdict.",
        sources_downloaded=False,external_models_called=False))
    sample = []
    # Deterministic prompt/output sample for assistant review. Not a human audit.
    for lang in ["ru","en"]:
        for label in ["educational","ordinary"]:
            for family in MAIN_FAMILIES:
                group = [p for p in augmented if p["language"]==lang and p["label"]==label and p["attack_family"]==family]
                sample.append(min(group,key=lambda p:sha("audit5:"+p["id"])))
    sample += [min([p for p in novel if p["language"]==lang and p["label"]==label and p["attack_family"]==family],key=lambda p:sha("audit5:"+p["id"]))
        for lang in ["ru","en"] for label in ["educational","ordinary"] for family in NOVEL_FAMILIES]
    write_jsonl(OUT/"review_sample.jsonl",sample)
    assert all(digest(BASE/name)==value for name,value in before.items())
    print(json.dumps(stats,ensure_ascii=False,indent=2))


if __name__=="__main__": main()
